#!/bin/bash

# docker ps
echo
echo 'docker ps'
docker ps -a

# docker stats
echo
echo 'docker stats:'
docker stats --no-stream

# docker_volume info
echo
echo 'docker volume info:'
docker system df -v | sed -n '/fmp_db_vol/,/^ *$/p'

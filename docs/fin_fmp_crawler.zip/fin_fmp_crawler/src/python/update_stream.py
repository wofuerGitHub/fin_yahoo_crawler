#!/usr/bin/env python

"""
File: update_stream.py
Author: Wolfgang Fuerst
Date: 2024-06-17
Description: 
    Streaming data:
    1) FX - items-list from reference FX-data --> write to fx
    2) Quotes - items-list from reference quote-data --> write to incl. eps
Runtime: ...
"""

import time
from mylib import config
from mylib import writeLog
from mylib import fmp_service
from mylib import fmp_db

# load config file
CONFIG = config.load_config('config.json')["fmp"]

# log entry
writeLog(CONFIG["file"]["log"], 'Start Update Stream', id = 'UTS')

# set configuration
fmp_service.set_configuration(\
    api_key = CONFIG["connection"]["api_key"],
    speed = CONFIG["connection"]["speed"],
    file_speed_control = CONFIG["file"]["speed_control"],
    debug = CONFIG["debug"],
    file_debug = CONFIG["file"]["debug"]
    )

fmp_db.set_configuration(\
    host = CONFIG["database"]["host"],
    port = CONFIG["database"]["port"],
    schema = CONFIG["database"]["schema"],
    user = CONFIG["database"]["user"],
    password = CONFIG["database"]["password"]
    )

# stream fx
def stream_fx():
    """
    Read last fx and write to MySQL table.

    Args:
        None.

    Returns:
        None.
    """
    sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
    connection = sql_engine.connect()
    REFERENCE_FX = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["reference_fx"])
    FX_EUR = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["fx"])
    data = fmp_db.get_mysql_symbol_list(
        connection, REFERENCE_FX, columns = ['symbol', 'currency', 'stream'])
    print(data)

    for index, row in data.iterrows():
        if bool(row['stream']) is True:
            data_set = fmp_service.get_fmp_quote("fx", row['symbol'], currency = 'EUR')
            print(data_set)
            try:
                fmp_db.put_dict_to_mysql(connection = connection, table = FX_EUR, \
                                        data_dict = data_set, unique_keys=['date','symbol'])
            except: # pylint: disable=bare-except
                writeLog(CONFIG["file"]["log"], ''+row['symbol']+' not stored', id = 'UTS')
    connection.close()
stream_fx()

# stream quotes
def stream_quotes():
    """
    Read last quote and write to MySQL table.

    Args:
        None.

    Returns:
        None.
    """
    sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
    connection = sql_engine.connect()
    REFERENCE_MAP = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["reference_map"])
    QUOTE_DATA = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["quote_eps"])
    data = fmp_db.get_mysql_symbol_list(
        connection, REFERENCE_MAP, columns = ['symbol', 'currency', 'stream'])
    print(data)

    for index, row in data.iterrows():
        if bool(row['stream']) is True:
            data_set = fmp_service.get_fmp_quote("quote", row['symbol'], currency = row['currency'])
            print(data_set)
            try:
                fmp_db.put_dict_to_mysql(
                    connection = connection, table = QUOTE_DATA,
                    data_dict = data_set, unique_keys=['date','symbol'])
            except: # pylint: disable=bare-except
                writeLog(CONFIG["file"]["log"], ''+row['symbol']+' not stored', id = 'UTS')
    connection.close()
stream_quotes()

# log entry
writeLog(CONFIG["file"]["log"], 'End Update Stream', id = 'UTS')

writeLog(CONFIG["file"]["log"], 'Wait Update Stream for '\
         +str(CONFIG["control"]["update_stream_delay"])+'s', id = 'UTS')
time.sleep(CONFIG["control"]["update_stream_delay"])

#!/usr/bin/env python

"""
File: insert_referencedata.py
Author: Wolfgang Fuerst
Date: 2025-02-23
Description: Adding a new timeseries / fundamental pair to reference table.
Runtime: ...
"""

# import sqlalchemy as sql

# from mylib.config import getDatabaseHost
# from mylib.config import getDatabaseSchema
# from mylib.config import getDatabaseUser
# from mylib.config import getDatabasePassword


# HOST = getDatabaseHost()
# DB = getDatabaseSchema()
# USER = getDatabaseUser()
# PW = getDatabasePassword()

import pandas as pd

from mylib import config
from mylib import writeLog
from mylib import fmp_db

# load config file
CONFIG = config.load_config('config.json')["fmp"]

# log entry
writeLog(CONFIG["file"]["log"], 'Configuration', id = 'CFG')

# set configuration
fmp_db.set_configuration(\
    host = CONFIG["database"]["host"],
    port = CONFIG["database"]["port"],
    schema = CONFIG["database"]["schema"],
    user = CONFIG["database"]["user"],
    password = CONFIG["database"]["password"]
    )

# CONNECTION_STRING = 'mysql+pymysql://'+USER+':'+PW+'@'+HOST+'/'+DB+''
# sql_engine = sql.create_engine(CONNECTION_STRING)

sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())

while True:
    skip = False
    print('Isin, Companyname or Symbol:')
    search = input()

    query = "call find_dataset('"+search+"');"
    result = pd.read_sql_query(query, sql_engine)

    with pd.option_context('display.max_rows', 300, 'display.max_columns', \
        20, 'display.max_colwidth', 20, 'display.expand_frame_repr', False):
        print(result)

    print('Correct # for price:')
    price_line = input()
    if price_line.isdecimal():
        symbol = result.iloc[[price_line]]['symbol'].values[0]
        name = result.iloc[[price_line]]['companyName'].values[0]
        currency = result.iloc[[price_line]]['currency'].values[0]
    else:
        skip = True

    if not skip:
        print('Correct # for ISIN:')
        isin_line = input()
        if isin_line.isdecimal():
            isin = ""+str(result.iloc[[isin_line]]['isin'].values[0])+""
        else:
            isin = 'NULL'

        print('Correct # for fundamental:')
        fun_line = input()
        if fun_line.isdecimal():
            symbol_fundamental = ""+str(result.iloc[[fun_line]]['symbol'].values[0])+""
        else:
            symbol_fundamental = 'NULL'

        print("Company:            ", name)
        print("Symbol Price:       ", symbol)
        print("Symbol Fundamental: ", symbol_fundamental)
        print("ISIN:               ", isin)

        print("")
        print('Update (y/n):')
        update = input()

        if update.lower() == 'y':
            data_set = {"symbol": symbol, "symbol_fundamental": symbol_fundamental, "isin": isin, "currency": currency}
            connection = sql_engine.connect()
            TABLE = fmp_db.get_metatable(sql_engine, \
                                        CONFIG["database"]["tables"]["reference_map"])
            fmp_db.put_dict_to_mysql(connection = connection, table = TABLE, \
                            data_dict = data_set, unique_keys=['symbol'])
            connection.close()
            # query = "INSERT INTO _reference_map (`symbol`, `symbol_fundamental`, `isin`, `currency`, `updated`) values ('"+symbol+"', "+symbol_fundamental+" , "+isin+" ,'"+currency+"', NOW(3)) ON DUPLICATE KEY UPDATE `symbol_fundamental`=  "+symbol_fundamental+" , `isin`=  "+isin+" , `currency`='"+currency+"', `updated`= NOW(3);"
            # print(query)
            # sql_engine.execute(query)
            # connection.execute(query)
            # connection.close()
            print("inserted")
        else:
            print("skipped")
    else:
        print("skipped")
#!/usr/bin/env python

"""
File: update_timeserie.py
Author: Wolfgang Fuerst
Date: 2025-04-20
Description: Updating timeseries.
    FX gets updated based on reference-data-sets
    QUOTE gets update based on reference-data table
    longTimeSerie is used to crawl as far into history as possible or grab only the last 30days
Runtime: ...
History:
    2025-04-20: improvement issue #3
"""

import time
import datetime
from mylib import config
from mylib import writeLog
from mylib import fmp_service
from mylib import fmp_db

# load config file
CONFIG = config.load_config('config.json')["fmp"]

# log entry
writeLog(CONFIG["file"]["log"], 'Start Update Timeseries', id = 'TSU')

# set configuration
fmp_service.set_configuration(\
    api_key = CONFIG["connection"]["api_key"],
    speed = CONFIG["connection"]["speed"],
    file_speed_control = CONFIG["file"]["speed_control"],
    debug = CONFIG["debug"],
    file_debug = CONFIG["file"]["debug"]
    )

fmp_db.set_configuration(\
    host = CONFIG["database"]["host"],
    port = CONFIG["database"]["port"],
    schema = CONFIG["database"]["schema"],
    user = CONFIG["database"]["user"],
    password = CONFIG["database"]["password"]
    )

# get fx
def get_fx():
    sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
    connection = sql_engine.connect()
    REFERENCE_FX = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["reference_fx"])
    FX_EUR = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["fx"])
    data = fmp_db.get_mysql_symbol_list(
        connection, REFERENCE_FX, columns = ['symbol', 'currency', 'longTimeSerie'])
    print(data)
    
    for index, row in data.iterrows():
        if bool(row['longTimeSerie']) is True:
            # long Time Serie update with close only
            data_set = []
            exit = False
            end = datetime.datetime.now()
            while not exit:
                start = end - datetime.timedelta(days=365*20)
                end_string = end.strftime("%Y-%m-%d")
                start_string = start.strftime("%Y-%m-%d")
                end = start - datetime.timedelta(days=1)
                new_data_set = fmp_service.get_fmp_timeseries_data(
                    "fx", row['symbol'], currency = 'EUR', long_format = False, start_date = start_string, end_date = end_string)
                if len(new_data_set) > 1:
                    data_set = data_set + new_data_set
                else:
                    exit = True
        else:
            # short time serie update with last 30days open, high, low, close
            data_set = fmp_service.get_fmp_timeseries_data(
                "fx", row['symbol'], currency = 'EUR', long_format = True, series_length = 30)            
        try:
            fmp_db.put_dict_to_mysql(
                connection = connection, table = FX_EUR,
                data_dict = data_set, unique_keys=['date','symbol'])
        except: # pylint: disable=bare-except
            writeLog(CONFIG["file"]["log"], ''+row['symbol']+' not stored', id = 'TSU')
        data_set = {'symbol': row['symbol'], 'currency': row['currency'], 'longTimeSerie': '0'}
        try:
            fmp_db.put_dict_to_mysql(
                connection = connection, table = REFERENCE_FX,
                data_dict = data_set, unique_keys=['symbol'])
        except: # pylint: disable=bare-except
            writeLog(CONFIG["file"]["log"], \
                    ''+row['symbol']+' longTimeSerie setting failed ', id = 'TSU')
    connection.close()
get_fx()

# get quotes
def get_quotes():
    sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
    connection = sql_engine.connect()
    REFERENCE_MAP = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["reference_map"])
    QUOTE_DATA = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["quote"])
    data = fmp_db.get_mysql_symbol_list(
        connection, REFERENCE_MAP, columns = ['symbol', 'currency', 'longTimeSerie'])
    print(data)

    for index, row in data.iterrows():

        if bool(row['longTimeSerie']) is True:
            data_set_lts = {'symbol': row['symbol'], 'currency': row['currency'], 'longTimeSerie': '1'}
            # long Time Serie update with close only
            data_set = []
            exit = False
            end = datetime.datetime.now()
            # slicing in packages of 20years and go back in history // issue is that this might interfere with they query frequency
            while not exit:
                start = end - datetime.timedelta(days=365*20)
                end_string = end.strftime("%Y-%m-%d")
                start_string = start.strftime("%Y-%m-%d")
                end = start - datetime.timedelta(days=1)
                new_data_set = fmp_service.get_fmp_timeseries_data(
                    "quote", row['symbol'], currency = row['currency'], long_format = False, start_date = start_string, end_date = end_string)
                if len(new_data_set) > 1:
                    data_set = data_set + new_data_set
                else:
                    exit = True
            # in case the crawl delivered more than 30 data-point, longTimeSerie is switched to 0
            if len(data_set) > 30:
                data_set_lts = {'symbol': row['symbol'], 'currency': row['currency'], 'longTimeSerie': '0'}
        else:
            data_set_lts = {'symbol': row['symbol'], 'currency': row['currency'], 'longTimeSerie': '0'}
            # short time serie update with last 30days open, high, low, close
            data_set = fmp_service.get_fmp_timeseries_data(
                "quote", row['symbol'], currency = row['currency'], long_format = True, series_length = 30)            
        try:
            fmp_db.put_dict_to_mysql(
                connection = connection, table = QUOTE_DATA,
                data_dict = data_set, unique_keys=['date','symbol'])
        except: # pylint: disable=bare-except
            writeLog(CONFIG["file"]["log"], ''+row['symbol']+' not stored', id = 'TSU')
        
        # set tracking shortTimeSerie or longTimeSerie based on success
        try:
            fmp_db.put_dict_to_mysql(
                connection = connection, table = REFERENCE_MAP,
                data_dict = data_set_lts, unique_keys=['symbol'])
        except: # pylint: disable=bare-except
            writeLog(CONFIG["file"]["log"], \
                    ''+row['symbol']+' longTimeSerie setting failed ', id = 'TSU')
    connection.close()
get_quotes()

# log entry
writeLog(CONFIG["file"]["log"], 'End Update Timeseries', id = 'TSU')

writeLog(CONFIG["file"]["log"], 'Wait Update Timeseries for '\
         +str(CONFIG["control"]["update_timeserie_delay"])+'s', id = 'TSU')
time.sleep(CONFIG["control"]["update_timeserie_delay"])

#!/usr/bin/env python

"""
File: update_symbolslist.py
Author: Wolfgang Fuerst
Date: 2024-02-10
Description: Get list of symbols from fmg and writes it to the respective table.
Runtime: 1min 15s for ~80.000 entries
"""

import time
from mylib import config
from mylib import writeLog
from mylib import fmp_service
from mylib import fmp_db

# load config file
CONFIG = config.load_config('config.json')["fmp"]

# log entry
writeLog(CONFIG["file"]["log"], 'Start Update Symbols List', id = 'USL')

# set configuration
fmp_service.set_configuration(\
    api_key = CONFIG["connection"]["api_key"],
    speed = CONFIG["connection"]["speed"],
    file_speed_control = CONFIG["file"]["speed_control"],
    debug = CONFIG["debug"],
    file_debug = CONFIG["file"]["debug"]
    )

fmp_db.set_configuration(\
    host = CONFIG["database"]["host"],
    port = CONFIG["database"]["port"],
    schema = CONFIG["database"]["schema"],
    user = CONFIG["database"]["user"],
    password = CONFIG["database"]["password"]
    )

for data_set in ['stock_list', 'etf_list']:

    # get data from fmp
    data = fmp_service.get_fmp_general_data(data_set)

    # write data to database
    sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
    connection = sql_engine.connect()
    SYMBOL_LIST = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["symbolslist"])
    fmp_db.put_dict_to_mysql(connection = connection, table = SYMBOL_LIST, data_dict = data, \
                            unique_keys=['symbol'], commitment_rate = 10000)
    connection.close()

# log entry
writeLog(CONFIG["file"]["log"], 'End Update Symbols List', id = 'USL')

writeLog(CONFIG["file"]["log"], 'Wait Update Symbols List for '\
         +str(CONFIG["control"]["update_symbolslist_delay"])+'s', id = 'USL')
time.sleep(CONFIG["control"]["update_symbolslist_delay"])

#!/usr/bin/python3

"""
File: yahoo_service.py
Author: Wolfgang Fuerst
Date: 2026-06-06
Description: Module to retrieve quote data from Yahoo Finance API.
"""

from urllib.request import urlopen, HTTPError
import datetime
import time
import json
import ssl
import certifi
from sqlalchemy.util import symbol
import yfinance as yf

# from . import writeLog

# CONFIGURATION

configuration = {
    "api_key": "eb6d52c06dd625f75f96fd9556e6c24f",  # api-key
    "speed": 50,                                    # query speed in queries / min
    "file_speed_control": "fmp_speed.ctl",          # file to control speed
    "debug": True,                                  # debug request
    "file_debug": "fmp_debug.log",                  # file to write debug info
}

def get_configuration():
    """
    Provides the actual configuration.

    Args:
        None

    Raises:
        None

    Returns:
        dict: set of configuration parameters
    """
    return configuration

def set_configuration(
    api_key: str = None,
    speed: float = None,
    file_speed_control: str = None,
    debug: bool = None,
    file_debug: str = None
):
    """
    Upates the configuration.

    Args:
        api_key (str): update the api_key
        speed (float): update the query speed
        file_speed_control (str): set file to control the speed
        debug (boolean): set debugging mode
        file_debug (str): set file to write debug data

    Raises:
        None

    Returns:
        None

    """
    if api_key is not None:
        configuration["api_key"] = api_key
    if speed is not None:
        configuration["speed"] = speed
    if file_speed_control is not None:
        configuration["file_speed_control"] = file_speed_control
    if debug is not None:
        configuration["debug"] = debug
    if file_debug is not None:
        configuration["file_debug"] = file_debug

# GENERAL QUERY

def control_speed():
    """
    Transforms the number of queries/time allowed with some wait time.

    Parameters:
        None
    
    Raises:
        FileNotFoundError: if file to control speed does not exist

    Returns:
        None
    """
    wait_time = 60 / configuration["speed"]                 # calculate pause between query
    file = configuration["file_speed_control"]              # get ctl file
    ts_now = time.time()                                    # get the actual timestamp
    try:                                                    # get next allowed timestamp
        with open(file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if lines:
                ts_allowed = float(lines[-1])
            else:
                ts_allowed = ts_now
    except FileNotFoundError:
        ts_allowed = ts_now + wait_time                     # in case of error wait by default
    if ts_now < ts_allowed:                                 # not allowed to query yet
        time_to_wait = ts_allowed - ts_now                  # calculate time_to_wait
        ts_allowed += wait_time                             # calculate the next allowed moment
    else:
        time_to_wait = wait_time                            # allowed to query, don't wait
        ts_allowed = ts_now + wait_time                     # calculate the next allowed moment
    with open(file, "w", encoding="utf-8") as f:            # write next allowed timestamp
        f.write(str(ts_allowed))
    time.sleep(time_to_wait)                                # sleep if necessary to control speed

def get_jsonparsed_data(url: str):
    """
    Receive the content of ``url``, parse it as JSON and return the object.

    Parameters:
        url (str): url to be queried

    Raises:
        None

    Returns:
        dict
    """
    try:
        control_speed()  # wait till it is allowed to execute the query
        if configuration["debug"]:
            writeLog(configuration["file_debug"], url)
        context = ssl.create_default_context(cafile=certifi.where())
        response = urlopen(url, context = context)
        data = response.read().decode("utf-8")
        return json.loads(data)
    except HTTPError as err:
        control_speed()  # wait in case of error - most time timeout
        print(err)
        return {}

# YAHOO QUERY FUNCTIONS
#   Grouping functions from version 1:
#       Single Quote:
#           get_quote(symbol:str)
#       General - not available for Yahoo Finance, only as placeholder for future use:
#           get_financial_statement_list() -> financial_statement_symbol_list
#           get_symbols_list(**kwargs) -> etf_list, stock_list
#       Timeseries:
#           get_fx_eur(currency:str, **kwargs)
#           get_quote_serie(symbol:str, **kwargs)
#       Single symbol related:
#           get_company_key_stats(company:str, api:str)
#           get_income_statement(company:str, api:str)
#           get_balance_sheet_statement(company:str, api:str)
#           get_cash_flow_statement(company:str, api:str)

def get_yahoo_quote(data_set: str = "quote", symbol: str = "AAPL", **kwargs):
    """
    Retrieve quote data from Yahoo Finance.

    Args:
        data_set (str): select data_set our of ["quote", "fx"] for quote or EUR-fx-rate
        symbol (str): symbol

    Keyword Args:
        currency (str): currency to overwrite

    Raises:
        None

    Returns:
        dict: queried data from Yahoo Finance
    """
    currency = kwargs.get("currency", "EUR")

    if data_set == "fx":
        data = yf.Ticker("EUR" + symbol + "=X")
        data = {'date': datetime.datetime.fromtimestamp(data.info.get("regularMarketTime", 0)).date().isoformat(),
                'symbol': data.info.get("symbol")[3:6],
                'open': data.info.get("regularMarketOpen"),
                'high': data.info.get("regularMarketDayHigh"),
                'low': data.info.get("regularMarketDayLow"),
                'close': data.info.get("regularMarketPrice"),
                'currency': "EUR"}
               
    elif data_set == "quote":
        data = yf.Ticker(symbol)
        data = {'date': datetime.datetime.fromtimestamp(data.info.get("regularMarketTime", 0)).date().isoformat(),
                'symbol': data.info.get("symbol"),
                'open': data.info.get("regularMarketOpen"),
                'high': data.info.get("regularMarketDayHigh"),
                'low': data.info.get("regularMarketDayLow"),
                'close': data.info.get("regularMarketPrice"),
                'eps': data.info.get("epsTrailingTwelveMonths"),
                'currency':data.info.get("currency")}
    if currency is not None:
        data["currency"] = currency
    return data

def get_yahoo_general_data(data_set: str = "etf_list", **kwargs):
    
    """
    Retrieve general data from from Yahoo Finance.
    Function only as placeholder for future use, as Yahoo Finance does not provide a general list of stocks or ETFs.

    Args:
        data_set (str): select data_set our of ["stock_list", "etf_list", "financial_statement_symbol_list"]
            stock_list: ...
            etf_list: ...
            financial_statement_symbol_list: ...

    Keyword Args:
        None

    Raises:
        None

    Returns:
        dict: queried data from Yahoo Finance
    """

def get_yahoo_timeseries_data(data_set: str = "quote", symbol: str = "AAPL", **kwargs):
    """
    Retrieve time series data (one per day) from Yahoo Finance.
    Args:
        data_set (str): select data_set our of ["quote", "fx"] for quote or EUR-fx-rate
        symbol (str): symbol or currency

    Keyword Args:
        start_date (str): start date
        end_date (str): end date
        series_length (int): number of historical elements
        long_format (bool): long format with open, close, etc. or close only
        currency (str): currency to overwrite
            
    Raises:
        None

    Returns:
        dict: queried data from Yahoo Finance
    """
    start_date = kwargs.get("start_date", None)
    end_date = kwargs.get("end_date", None)
    series_length = kwargs.get("series_length", None)
    long_format = kwargs.get("long_format", True)
    currency = kwargs.get("currency", "EUR")

    if data_set == "fx":
        symbol = "EUR" + symbol + "=X"

    params = {
        "tickers": symbol,
        "interval": "1d",
        "progress": False,
        "auto_adjust": False,
    }

    if series_length is not None: 
        params["period"] = str(series_length) + "d"
    else:
        if start_date is not None: params["start"] = start_date
        if end_date is not None: params["end"] = end_date

    try:
        df = yf.download(**params)

        # Flatten columns: keep first level: Close, High, Low, Open, Volume
        df.columns = df.columns.get_level_values(0)

        # Convert index date to normal column
        df = df.reset_index()

        # Format date as YYYY-MM-DD
        df["Date"] = df["Date"].dt.date.astype(str)

        # Change column without spaces and lowercase first letter
        df.columns = [col.replace(" ", "") for col in df.columns]
        df.columns = [col[:1].lower() + col[1:] if col else col for col in df.columns]

        # Add symbol and currency columns
        df["symbol"] = symbol
        df["currency"] = currency

        # Remove "EUR" and "=X" from symbol for fx data
        if data_set == "fx":
            df["symbol"] = df["symbol"].str.replace("EUR", "", regex=False)
            df["symbol"] = df["symbol"].str.replace("=X", "", regex=False)

        # Remove Open, High, Low if not wanted as long_format
        if not long_format:
            df = df[[col for col in ["date", "symbol", "currency", "close"] if col in df.columns]]

        # Reorder columns: date, symbol, currency, ...
        first = ["date", "symbol", "currency"]
        df = df[first + [col for col in df.columns if col not in first]]
        data = df.to_dict(orient="records")

        return data
    except:
        return [{}]

def get_yahoo_single_symbol_data(data_set: str = "profile", symbol: str = "AAPL", **kwargs):
    """
    Retrieve data for specific symbol from Yahoo Finance.
    https://site.financialmodelingprep.com/developer/docs/companies-key-stats-free-api#Python

    Args:
        data_set (str): select data_set out of ["profile", "income", "balance", "cashflow"] for comp. profile or fundamental data
        symbol (str): symbol or currency
    
    Keyword Args:
        api_key (str): api-key
        period (str): select period out of ["quarterly", "annual"]
        limit (int): number of periods

    Raises:
        None

    Returns:
        dict: queried data from FMP
    """
    period = kwargs.get("period", "annual")
    limit = kwargs.get("limit", 10)

    if not isinstance(symbol, str): raise TypeError

    def safe_div(a, b):
        return a / b if a is not None and b not in (None, 0) else None

    def val(row, name):
        value = row.get(name)
        return None if value != value else value  # handles NaN
    
    def yahoo_balance_row_mapping(row, symbol, currency=None, period="FY"):
        # Balance Sheet
        # date: str, "2026-09-30"
        # symbol: str, "AAPL"
        # reportedCurrency: str, "USD"
        # calendarYear: str, "2026" as substring of date
        # period: str, "FY"
        # totalStockholdersEquity
        # preferredStock

        total_stockholders_equity = val(row, "Stockholders Equity")
        preferred_stock = val(row, "Preferred Stock") or 0

        date = row["date"]

        return {
            "date": date,
            "symbol": symbol,
            "reportedCurrency": currency,
            "calendarYear": str(date)[:4],
            "period": period,
            "totalStockholdersEquity": total_stockholders_equity,
            "preferredStock": preferred_stock
        }

    def yahoo_income_row_mapping(row, symbol, currency=None, period="FY"):
        # Income Statement
        # date: str, "2026-09-30"
        # symbol: str, "AAPL"
        # reportedCurrency: str, "USD"
        # calendarYear: str, "2026" as substring of date
        # period: str, "FY"
        # revenue
        # grossProfit
        # grossProfitRatio
        # researchAndDevelopmentExpenses
        # interestExpense
        # operatingIncome
        # netIncome
        # weightedAverageShsOut

        date = row["date"]
        revenue = val(row, "Total Revenue")
        gross_profit = val(row, "Gross Profit")
        research_and_development_expenses = val(row, "Research And Development")
        interest_expense = val(row, "Interest Expense Non Operating") or val(row, "Interest Expense")
        operating_income = val(row, "Operating Income") or val(row, "Total Operating Income As Reported")
        net_income = val(row, "Net Income")
        weighted_average_shs_out = val(row, "Basic Average Shares")
        
        return {
            "date": date,
            "symbol": symbol,
            "reportedCurrency": currency,
            "calendarYear": str(date)[:4],
            "period": period,
            "revenue": revenue,
            "grossProfit": gross_profit,
            "grossProfitRatio": safe_div(gross_profit, revenue),
            "researchAndDevelopmentExpenses": research_and_development_expenses,
            "interestExpense": interest_expense,
            "operatingIncome": operating_income,
            "netIncome": net_income,
            "weightedAverageShsOut": weighted_average_shs_out,
        }

    def yahoo_cashflow_row_mapping(row, symbol, currency=None, period="FY"):
        # Cashflow Statement
        # date: str, "2026-09-30"
        # symbol: str, "AAPL"
        # reportedCurrency: str, "USD"
        # calendarYear: str, "2026" as substring of date
        # period: str, "FY"
        # dividendsPaid
        # operatingCashFlow

        date = row["date"]
        dividends_paid = (val(row, "Cash Dividends Paid") or val(row, "Common Stock Dividend Paid"))
        operating_cash_flow = val(row, "Operating Cash Flow") or val(row, "Cash Flow From Continuing Operating Activities")


        return {
            "date": date,
            "symbol": symbol,
            "reportedCurrency": currency,
            "calendarYear": str(date)[:4],
            "period": period,
            "dividendsPaid": -dividends_paid if dividends_paid is not None else None,
            "operatingCashFlow": operating_cash_flow            
        }


    if data_set == "profile":
        data = yf.Ticker(symbol)
        data = {
            'date': datetime.datetime.fromtimestamp(data.info.get("regularMarketTime", 0)).date().isoformat(),
            'symbol': data.info.get("symbol"),
            'price': data.info.get("regularMarketPrice"),
            'beta': data.info.get("beta"),
            'volAvg': data.info.get("averageVolume"),
            'mktCap': data.info.get("marketCap"),
            'lastDiv': data.info.get("dividendRate"),
            'range': data.info.get("fiftyTwoWeekRange").replace(" ", ""),
            'changes': data.info.get("regularMarketChange"),
            'companyName': data.info.get("longName"),
            'currency': data.info.get("currency"),
            'cik': None,
            'isin': None,
            'cusip': None,
            'exchange': data.info.get("fullExchangeName"),
            'exchangeShortName': data.info.get("exchange"),
            'industry': data.info.get("industry"),
            'website': data.info.get("website"),
            'description': data.info.get("longBusinessSummary"),
            'ceo': data.info.get("companyOfficers")[0]["name"] if data.info.get("companyOfficers") else None,
            'sector': data.info.get("sector"),
            'country': data.info.get("country"),
            'fullTimeEmployees': data.info.get("fullTimeEmployees"),
            'phone': data.info.get("phone"),
            'address': data.info.get("address1"),
            'city': data.info.get("city"),
            'state': data.info.get("state"),
            'zip': data.info.get("zip"),
            'dcfDiff': None,
            'dcf': None,
            'image': None,
            'ipoDate': datetime.datetime.fromtimestamp(data.info.get("firstTradeDateMilliseconds", 0)/1000).date().isoformat(),
            'defaultImage': None,
            'isEtf': data.info.get("quoteType"),    
            'IsActivelyTrading': data.info.get("regularMarketPrice") is not None,
            'isAdr': None,
            'isFund': None}
    elif data_set == "income":
        ticker = yf.Ticker(symbol)
        income = ticker.incomestmt

        df = income.T.reset_index()
        df = df.rename(columns={"index": "date"})
        df["date"] = df["date"].dt.date.astype(str)

        currency = ticker.info.get("financialCurrency") or ticker.info.get("currency")

        records = [
            yahoo_income_row_mapping(row, symbol=symbol, currency=currency, period="FY")
                for row in df.to_dict(orient="records")
        ]

        data = [records[0], records[1], records[2]]
        # url = "https://financialmodelingprep.com/api/v3/income-statement/" + symbol + "?" + "period=" + period + "&limit=" + str(limit) + "&"
    elif data_set == "balance":
        ticker = yf.Ticker(symbol)
        balance = ticker.balancesheet

        df = balance.T.reset_index()
        df = df.rename(columns={"index": "date"})
        df["date"] = df["date"].dt.date.astype(str)

        currency = ticker.info.get("financialCurrency") or ticker.info.get("currency")

        records = [
            yahoo_balance_row_mapping(row, symbol=symbol, currency=currency, period="FY")
                for row in df.to_dict(orient="records")
        ]

        data = [records[0], records[1], records[2]]
        # url = "https://financialmodelingprep.com/api/v3/balance-sheet-statement/" + symbol + "?" + "period=" + period + "&limit=" + str(limit) + "&"
    elif data_set == "cashflow":
        ticker = yf.Ticker(symbol)
        cashflow = ticker.cashflow

        df = cashflow.T.reset_index()
        df = df.rename(columns={"index": "date"})
        df["date"] = df["date"].dt.date.astype(str)

        currency = ticker.info.get("financialCurrency") or ticker.info.get("currency")

        records = [
            yahoo_cashflow_row_mapping(row, symbol=symbol, currency=currency, period="FY")
                for row in df.to_dict(orient="records")
        ]

        data = [records[0], records[1], records[2]]
        # url = "https://financialmodelingprep.com/api/v3/cash-flow-statement/" + symbol + "?" + "period=" + period + "&limit=" + str(limit) + "&"
    else:
        return None
    
    return data

print(get_yahoo_single_symbol_data("balance", "JPM"))
# print(get_yahoo_single_symbol_data("cashflow", "AAPL"))
# print(get_yahoo_single_symbol_data("income", "AAPL"))

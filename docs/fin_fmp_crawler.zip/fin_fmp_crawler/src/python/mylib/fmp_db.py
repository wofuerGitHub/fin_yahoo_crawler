"""investment db module"""

#!/usr/bin/python3

import pandas as pd
from sqlalchemy import create_engine, MetaData, select
from sqlalchemy.dialects.mysql import insert
from sqlalchemy.sql import func

configuration = {
    "host": "127.0.0.1",
    "port": "3306",
    "schema": "fmp",
    "user": "fmp",
    "password": "fmp"
}

def get_configuration():
    """
    Provides the actual configuration.

    Args:
        None

    Raises:
        None

    Returns:
        dict: set of configuration parameters
    """
    return configuration

def set_configuration(
    host: str = None,
    port: str = None,
    schema: str = None,
    user: str = None,
    password: str = None
):
    """
    Updates the configuration.

    Args:
        host (str, optional): host IP, e.g. 127.0.0.1. Defaults to None.
        port (str, optional): host PORT, e.g. 3306. Defaults to None.
        schema (str, optional): host SCHEMA, e.g. fmp. Defaults to None.
        user (str, optional): host USER, e.g. fmp. Defaults to None.
        password (str, optional): host PASSWORD, e.g. fmp. Defaults to None.

    Raises:
        None

    Returns:
        None
    
    """
    if host is not None:
        configuration["host"] = host
    if port is not None:
        configuration["port"] = port
    if schema is not None:
        configuration["schema"] = schema
    if user is not None:
        configuration["user"] = user
    if password is not None:
        configuration["password"] = password

def create_sql_engine(connection_data):
    """
    Create an engine for MySQL connection.
    """
    if connection_data["host"] is not None:
        HOST = connection_data["host"]
    else:
        HOST = "127.0.0.1"
    if connection_data["port"] is not None:
        PORT = connection_data["port"]
    else:
        PORT = "3306"
    USER = connection_data["user"]
    PASSWORD = connection_data["password"]
    SCHEMA = connection_data["schema"]
    CONNECTION_STRING = 'mysql+pymysql://'+USER+':'+PASSWORD+'@'+HOST+':'+PORT+'/'+SCHEMA+''
    return create_engine(CONNECTION_STRING)

def get_metatable(engine, table: str):
    """
    Get a table from a MySQL database.

    Args:
        engine (sqlalchemy.engine.base.Engine): SQLAlchemy engine.
        table (str): Name of the table to be retrieved.

    Returns:
        sqlalchemy.schema.Table: Table object.
    """
    meta = MetaData()
    meta.reflect(engine)
    return meta.tables[table]

def get_mysql_data(connection, table:str, **kwargs):
    """
    Read a MySQL table into a pandas DataFrame.

    Args:
        table (sqlalchemy.sql.schema.Table): table to be read into a DataFrame.
        columns (array): columns to be read
        filter_symbol (str): filters for a certain string
        filter_date (str_time): filters for everything newer than a given datetime
        filter_updated (str_time): filters for everything newer than given datetime
        order_by (str): column based on to be orderd
        order_desc (bool): True on descending order
        limit (int): rows to read

    Returns:
        dataframe: DataFrame containing the data from the table.

    Updates:
        2025-01-11 Integration of filter_date for analytics
        2025-01-22 Integration of filter_symbol
    """
    columns = kwargs.get('columns', table.columns.keys())
    filter_symbol = kwargs.get('filter_symbol', None)
    filter_date = kwargs.get('filter_date', None)
    filter_updated = kwargs.get('filter_updated', None)
    order_by = kwargs.get('order_by', None)
    order_desc = kwargs.get('order_desc', False)
    limit = kwargs.get('limit', None)
    stmt = select(*[getattr(table.c, attr) for attr in columns]).limit(limit)
    if filter_symbol is not None:
        stmt = stmt.filter(getattr(table.c, 'symbol') == filter_symbol)    
    if filter_date is not None:
        stmt = stmt.filter(getattr(table.c, 'date') >= filter_date)
    if filter_updated is not None:
        stmt = stmt.filter(getattr(table.c, 'updated') >= filter_updated)
    if order_by is not None:
        if order_desc is True:
            stmt = stmt.order_by(getattr(table.c, order_by).desc())
        else:
            stmt = stmt.order_by(getattr(table.c, order_by).asc())
    return pd.read_sql_query(stmt, connection)

def get_mysql_symbol_list(connection, table:str, **kwargs):
    """
    """
    # column = kwargs.get("column", ["symbol", "currency"])
    # stmt = select(table.c["symbol", "currency"]).group_by(table.c["symbol", "currency"])
    columns = kwargs.get('columns', ['symbol', 'currency'])
    # stmt = select(table.c[*columns]).group_by(table.c[*columns])
    stmt = select(*[getattr(table.c, attr) for attr in columns]).group_by(*[getattr(table.c, attr) for attr in columns])
    # stmt = select(table.c["symbol", "currency"]).group_by(table.c["symbol", "currency"])
    return pd.read_sql_query(stmt, connection)

def put_dict_to_mysql(connection, table: str, data_dict: dict, unique_keys: list, **kwargs):
    """
    Write a dictionary to a MySQL table.

    Args:
        connection (sqlalchemy.engine.base.Connection): Connection to MySQL database.
        table (str): Name of the table to which the data will be written.
        data_dict (dict): Dictionary of data to be written to the table.
        unique_keys (list): List of column names that will be used as unique keys for the table.
    
    Keyword Args:
        commitment_rate (int): number for items to transmit per block

    Raise:
        Exception: If writing to database fails.

    Returns:
    None
    """
    commitment_rate = kwargs.get("commitment_rate", 10000)

    if isinstance(data_dict, dict): data_dict = [data_dict] # single dict put in an array

    # fix sqlalchemy.exc.CompileError: Unconsumed column names: column_name
    column_names = table.columns.keys()
    data_dict = [{k: v for k, v in d.items() if k in column_names} for d in data_dict]

    if isinstance(data_dict, list):
        if len(data_dict) >= 1:
            i_max = len(data_dict)-1
            for i, data_set in enumerate(data_dict):
                update_data_set = {k: v for k, v in data_set.items() if k not in unique_keys}
                stmt = insert(table).values(data_set).on_duplicate_key_update(
                    **update_data_set, updated = func.current_timestamp())
                try:
                    connection.execute(stmt)
                    if i % commitment_rate == 0 or i == i_max:
                        connection.commit()
                        print('commit done')
                except:
                    connection.rollback()
                    raise Exception("Writing to database failed and was rolled back")
        else:
            raise Exception("No data to write")

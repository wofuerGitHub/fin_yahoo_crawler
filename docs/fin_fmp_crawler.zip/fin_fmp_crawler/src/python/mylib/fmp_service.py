#!/usr/bin/python3

"""
File: fmp_service.py
Author: Wolfgang Fuerst
Date: 2024-02-10
Description: Module to retrieve quote data from FMP (Financial Modeling Prep) API.
"""

from urllib.request import urlopen, HTTPError
import datetime
import time
import json
import ssl
import certifi

from . import writeLog

# CONFIGURATION

configuration = {
    "api_key": "eb6d52c06dd625f75f96fd9556e6c24f",  # api-key
    "speed": 50,                                    # query speed in queries / min
    "file_speed_control": "fmp_speed.ctl",          # file to control speed
    "debug": True,                                  # debug request
    "file_debug": "fmp_debug.log",                  # file to write debug info
}

def get_configuration():
    """
    Provides the actual configuration.

    Args:
        None

    Raises:
        None

    Returns:
        dict: set of configuration parameters
    """
    return configuration

def set_configuration(
    api_key: str = None,
    speed: float = None,
    file_speed_control: str = None,
    debug: bool = None,
    file_debug: str = None
):
    """
    Upates the configuration.

    Args:
        api_key (str): update the api_key
        speed (float): update the query speed
        file_speed_control (str): set file to control the speed
        debug (boolean): set debugging mode
        file_debug (str): set file to write debug data

    Raises:
        None

    Returns:
        None

    """
    if api_key is not None:
        configuration["api_key"] = api_key
    if speed is not None:
        configuration["speed"] = speed
    if file_speed_control is not None:
        configuration["file_speed_control"] = file_speed_control
    if debug is not None:
        configuration["debug"] = debug
    if file_debug is not None:
        configuration["file_debug"] = file_debug

# GENERAL QUERY

def control_speed():
    """
    Transforms the number of queries/time allowed with some wait time.

    Parameters:
        None
    
    Raises:
        FileNotFoundError: if file to control speed does not exist

    Returns:
        None
    """
    wait_time = 60 / configuration["speed"]                 # calculate pause between query
    file = configuration["file_speed_control"]              # get ctl file
    ts_now = time.time()                                    # get the actual timestamp
    try:                                                    # get next allowed timestamp
        with open(file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if lines:
                ts_allowed = float(lines[-1])
            else:
                ts_allowed = ts_now
    except FileNotFoundError:
        ts_allowed = ts_now + wait_time                     # in case of error wait by default
    if ts_now < ts_allowed:                                 # not allowed to query yet
        time_to_wait = ts_allowed - ts_now                  # calculate time_to_wait
        ts_allowed += wait_time                             # calculate the next allowed moment
    else:
        time_to_wait = wait_time                            # allowed to query, don't wait
        ts_allowed = ts_now + wait_time                     # calculate the next allowed moment
    with open(file, "w", encoding="utf-8") as f:            # write next allowed timestamp
        f.write(str(ts_allowed))
    time.sleep(time_to_wait)                                # sleep if necessary to control speed

def get_jsonparsed_data(url: str):
    """
    Receive the content of ``url``, parse it as JSON and return the object.

    Parameters:
        url (str): url to be queried

    Raises:
        None

    Returns:
        dict
    """
    try:
        control_speed()  # wait till it is allowed to execute the query
        if configuration["debug"]:
            writeLog(configuration["file_debug"], url)
        context = ssl.create_default_context(cafile=certifi.where())
        response = urlopen(url, context = context)
        data = response.read().decode("utf-8")
        return json.loads(data)
    except HTTPError as err:
        control_speed()  # wait in case of error - most time timeout
        print(err)
        return {}

# FMP QUERY FUNCTIONS
#   Grouping functions from version 1:
#       Single Quote:
#           get_quote(api:str, symbol:str)
#       General:
#           get_financial_statement_list(api:str) -> financial_statement_symbol_list
#           get_symbols_list(api:str, **kwargs) -> etf_list, stock_list
#       Timeseries:
#           get_fx_eur(api:str, currency:str, **kwargs)
#           get_quote_serie(api:str, symbol:str, **kwargs)
#       Single symbol related:
#           get_company_key_stats(company:str, api:str)
#           get_income_statement(company:str, api:str)
#           get_balance_sheet_statement(company:str, api:str)
#           get_cash_flow_statement(company:str, api:str)

def get_fmp_quote(data_set: str = "quote", symbol: str = "AAPL", **kwargs):
    """
    Retrieve quote data from FMP (Financial Modeling Prep) API.

    Args:
        data_set (str): select data_set our of ["quote", "fx"] for quote or EUR-fx-rate
        symbol (str): symbol

    Keyword Args:
        api_key (str): api-key
        currency (str): currency to overwrite

    Raises:
        None

    Returns:
        dict: queried data from FMP
    """
    api_key = kwargs.get("api_key", configuration["api_key"])
    currency = kwargs.get("currency", "EUR")

    if data_set == "fx":
        url = "https://financialmodelingprep.com/api/v3/quote/EUR" + symbol + "?apikey=" + api_key
    elif data_set == "quote":
        url = "https://financialmodelingprep.com/api/v3/quote/" + symbol + "?apikey=" + api_key
    
    data = get_jsonparsed_data(url)[0]
    
    if data_set == "fx":
        data = {'date':datetime.datetime.fromtimestamp(data['timestamp']).strftime("%Y-%m-%d"), \
                'symbol':data['symbol'][3:],
                'open':data['open'],
                'high':data['dayHigh'],
                'low':data['dayLow'],
                'close':data['price'],
                'currency':currency}

    if data_set == "quote":
        data = {'date':datetime.datetime.fromtimestamp(data['timestamp']).strftime("%Y-%m-%d"), \
                'symbol':data['symbol'],
                'open':data['open'],
                'high':data['dayHigh'],
                'low':data['dayLow'],
                'close':data['price'],
                'eps':data['eps'],
                'currency':currency}

    """
    update = {'currency':currency
    datanew_dicts = [{**d,**update} for d in my_dicts]
    """

    return data

def get_fmp_general_data(data_set: str = "etf_list", **kwargs):
    """
    Retrieve general data from FMP (Financial Modeling Prep) API.

    Args:
        data_set (str): select data_set our of ["stock_list", "etf_list", "financial_statement_symbol_list"]
            stock_list: https://site.financialmodelingprep.com/developer/docs/etf-list-api/?direct=true
            etf_list: https://site.financialmodelingprep.com/developer/docs/stock-market-quote-free-api/?direct=true
            financial_statement_symbol_list: https://site.financialmodelingprep.com/developer/docs/financial-statements-list-api/?direct=true#Python

    Keyword Args:
        api_key (str): api-key

    Raises:
        None

    Returns:
        dict: queried data from FMP
    """
    api_key = kwargs.get("api_key", configuration["api_key"])
    if data_set == "financial_statement_symbol_list":
        url = "https://financialmodelingprep.com/api/v3/financial-statement-symbol-lists?apikey=" \
            + api_key
    elif data_set == "stock_list":
        url = "https://financialmodelingprep.com/api/v3/stock/list?apikey=" + api_key
    elif data_set == "etf_list":
        url = "https://financialmodelingprep.com/api/v3/etf/list?apikey=" + api_key
    else:
        return {}
    return get_jsonparsed_data(url)

def get_fmp_timeseries_data(data_set: str = "quote", symbol: str = "AAPL", **kwargs):
    """
    Retrieve time series data (one per day) from FMP (Financial Modeling Prep) API.
    https://site.financialmodelingprep.com/developer/docs/historical-stock-data-free-api/?direct=true
    https://financialmodelingprep.com/api/v3/historical-price-full/MSFT?from=2018-03-12&to=2019-03-12&apikey=demo

    Args:
        data_set (str): select data_set our of ["quote", "fx"] for quote or EUR-fx-rate
        symbol (str): symbol or currency

    Keyword Args:
        api_key (str): api-key
        start_date (str): start date
        end_date (str): end date
        series_length (int): number of historical elements
        long_format (bool): long format with open, close, etc. or close only
        currency (str): currency to overwrite
            
    Raises:
        None

    Returns:
        dict: queried data from FMP
    """
    api_key = kwargs.get("api_key", configuration["api_key"])
    start_date = kwargs.get("start_date", None)
    end_date = kwargs.get("end_date", None)
    series_length = kwargs.get("series_length", None)
    long_format = kwargs.get("long_format", True)
    currency = kwargs.get("currency", "EUR")

    url = "https://financialmodelingprep.com/api/v3/historical-price-full/"
    if data_set == "quote": url += symbol + "?"
    elif data_set == "fx": url += "EUR" + symbol + "?"
    else:
        return None
    if start_date:
        url += "from=" + start_date + "&"
    if end_date:
        url += "to=" + end_date + "&"
    if series_length:
        url += "timeseries=" + str(series_length) + "&"
    if not long_format:
        url += "serietype=line&"
    url += "apikey=" + api_key

    try:
        data = get_jsonparsed_data(url)['historical']
        data = [dict(item, **{'symbol':symbol, 'currency': currency}) for item in data]
        return data
    except:
        return [{}]

    """
    issue: the returned dataset has neither a symbol nor a currency
    result = [dict(item, **{'elem':'value'}) for item in myList]
    try:
        return get_jsonparsed_data(url)['historical']
    except :
        return {}
    """

def get_fmp_single_symbol_data(data_set: str = "profile", symbol: str = "AAPL", **kwargs):
    """
    Retrieve data for specific symbol from FMP (Financial Modeling Prep) API.
    https://site.financialmodelingprep.com/developer/docs/companies-key-stats-free-api#Python

    Args:
        data_set (str): select data_set out of ["profile", "income", "balance", "cashflow"] for comp. profile or fundamental data
        symbol (str): symbol or currency
    
    Keyword Args:
        api_key (str): api-key
        period (str): select period out of ["quarterly", "annual"]
        limit (int): number of periods

    Raises:
        None

    Returns:
        dict: queried data from FMP
    """
    api_key = kwargs.get("api_key", configuration["api_key"])
    period = kwargs.get("period", "annual")
    limit = kwargs.get("limit", 10)

    if not isinstance(symbol, str): raise TypeError

    if data_set == "profile":
        url = "https://financialmodelingprep.com/api/v3/profile/" + symbol + "?"
    elif data_set == "income":
        url = "https://financialmodelingprep.com/api/v3/income-statement/" + symbol + "?" + "period=" + period + "&limit=" + str(limit) + "&"
    elif data_set == "balance":
        url = "https://financialmodelingprep.com/api/v3/balance-sheet-statement/" + symbol + "?" + "period=" + period + "&limit=" + str(limit) + "&"
    elif data_set == "cashflow":
        url = "https://financialmodelingprep.com/api/v3/cash-flow-statement/" + symbol + "?" + "period=" + period + "&limit=" + str(limit) + "&"
    else:
        return None
    url += "apikey=" + api_key
    return get_jsonparsed_data(url)

# TESTING

def test_kwargs(data_set: str = "quote", symbol: str = "AAPL", **kwargs):
    api_key  =kwargs.get("api_key", configuration["api_key"])
    print(data_set)
    print(symbol)
    print(kwargs)
    print(api_key)


def get_jsonparsed_dummy():
    control_speed()  # wait till it is allowed to execute the query
    return {}

def get_dummy():
    get_jsonparsed_dummy()

def test_function():
    print(get_configuration())
    set_configuration(speed = 5.0, debug = True)
    print(get_configuration())
    for i in range(10):
        print(time.time())
        get_dummy()
    print(time.time())

#!/usr/bin/env python3

"""
File: test_fmp_service.py
Author: Test Suite
Date: 2026-06-06
Description: Comprehensive test suite for fmp_service module.
"""

import pytest
from mylib import config
from mylib import fmp_service

CONFIG = config.load_config('config.json')["fmp"]
fmp_service.set_configuration(\
    api_key = CONFIG["connection"]["api_key"],
    speed = CONFIG["connection"]["speed"],
    file_speed_control = CONFIG["file"]["speed_control"],
    debug = CONFIG["debug"],
    file_debug = CONFIG["file"]["debug"]
    )

def test_get_single_quote():
    """Test fetching a quote for AAPL.\n
    {'date': '2026-06-05', 'symbol': 'AAPL', 'open': 312.99, 'high': 315.17, 'low': 307.15, 'close': 307.34, 'eps': 8.28, 'currency': 'USD'}"""
    quote = fmp_service.get_fmp_quote("quote", "AAPL", currency = "USD")
    assert quote is not None
    assert quote["date"] is not None
    assert quote["symbol"] == "AAPL"
    assert quote["currency"] == "USD"
    assert quote["open"] is not None
    assert quote["high"] is not None
    assert quote["low"] is not None
    assert quote["close"] is not None
    assert quote["eps"] is not None
    assert quote["currency"] == "USD"

def test_get_multiple_quotes():
    """Test fetching multiple quotes for AAPL.\n
    [{'date': '2026-06-05', 'symbol': 'AAPL', 'open': 312.99, 'high': 315.17, 'low': 307.15, 'close': 307.34, 'eps': 8.28, 'currency': 'USD'}, {'date': '2026-06-04', 'symbol': 'AAPL', 'open': 310.00, 'high': 320.00, 'low': 300.00, 'close': 310.00, 'eps': 8.28, 'currency': 'USD'}]"""
    quotes = fmp_service.get_fmp_timeseries_data("quote", "AAPL", currency = "USD", long_format = False, series_length = 5)
    assert quotes is not None
    assert isinstance(quotes, list)
    assert len(quotes) == 5
    for quote in quotes:
        assert quote["date"] is not None
        assert quote["symbol"] == "AAPL"
        assert quote["currency"] == "USD"
        assert quote["close"] is not None

# if __name__ == "__main__": pytest.main([__file__, "-v", "--tb=short"])

print(fmp_service.get_fmp_timeseries_data("quote", "AAPL", currency = "EUR", long_format = True, series_length = 30))
print(fmp_service.get_fmp_timeseries_data("fx", "USD", currency = "EUR", long_format = True, series_length = 30))
print(fmp_service.get_fmp_timeseries_data("quote", "AAPL", currency = "USD", long_format = False,  start_date = "2015-06-11", end_date = "2016-06-11"))
print(fmp_service.get_fmp_timeseries_data("fx", "USD", currency = "USD", long_format = False,  start_date = "2015-06-11", end_date = "2016-06-11"))
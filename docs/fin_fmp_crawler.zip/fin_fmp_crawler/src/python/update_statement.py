#!/usr/bin/env python

"""
File: update_statement.py
Author: Wolfgang Fuerst
Date: 2024-02-11
Description: ...
Runtime: ...

Args:
    income, cashflow, balance
"""

import sys
import time
from mylib import config
from mylib import writeLog
from mylib import fmp_service
from mylib import fmp_db

if sys.argv[-1] in ["income", "cashflow", "balance"]:
    statement_type = sys.argv[-1]
else:
    statement_type = "income"

# load config file
CONFIG = config.load_config('config.json')["fmp"]

# parameterizing the kind of statement to go for
if statement_type == "income":
    # income statement setting
    log_id = "INS"
    profile = "income"
    target_table = CONFIG["database"]["tables"]["income"]
elif statement_type == "cashflow":
    # cashflow statement setting
    log_id = "CFS"
    profile = "cashflow"
    target_table = CONFIG["database"]["tables"]["cashflow"]
elif statement_type == "balance":
    # balance sheet setting
    log_id = "BSS"
    profile = "balance"
    target_table = CONFIG["database"]["tables"]["balance"]

# log entry
writeLog(CONFIG["file"]["log"], 'Start Update Statement', id = log_id)

# set configuration
fmp_service.set_configuration(\
    api_key = CONFIG["connection"]["api_key"],
    speed = CONFIG["connection"]["speed"],
    file_speed_control = CONFIG["file"]["speed_control"],
    debug = CONFIG["debug"],
    file_debug = CONFIG["file"]["debug"]
    )

fmp_db.set_configuration(\
    host = CONFIG["database"]["host"],
    port = CONFIG["database"]["port"],
    schema = CONFIG["database"]["schema"],
    user = CONFIG["database"]["user"],
    password = CONFIG["database"]["password"]
    )

# get data data database
sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
connection = sql_engine.connect()
if CONFIG['control']['update_statement_all']:
    SOURCE_TABLE = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["companykeystats"])
    data = fmp_db.get_mysql_data(connection, SOURCE_TABLE, columns = ["symbol"])
else:
    SOURCE_TABLE = fmp_db.get_metatable(sql_engine, CONFIG["database"]["tables"]["reference_map"])
    data = fmp_db.get_mysql_data(connection, SOURCE_TABLE, columns = ["symbol_fundamental"])
    data.rename(columns = {"symbol_fundamental": "symbol"}, inplace = True)

print(data)
TARGET_TABLE = fmp_db.get_metatable(sql_engine, target_table)
for index, row in data.iterrows():
    symbol = str(row['symbol']) # avoid 'None' finding errors
    print(symbol)
    # try query and try store data
    try:
        data_set = fmp_service.get_fmp_single_symbol_data(profile, symbol)
        try:
            fmp_db.put_dict_to_mysql(connection = connection, table = TARGET_TABLE, \
                                    data_dict = data_set, unique_keys=['date', 'symbol', 'reportedCurrency'])
        except: # pylint: disable=bare-except
            writeLog(CONFIG["file"]["log"], ''+symbol+' not stored', id = log_id)
    except: # pylint: disable=bare-except
        writeLog(CONFIG["file"]["log"], ''+symbol+' not found', id = log_id)
connection.close()

# log entry
writeLog(CONFIG["file"]["log"], 'End Update Statement', id = log_id)

writeLog(CONFIG["file"]["log"], 'Wait Update Statement for '\
         +str(CONFIG["control"]["update_statement_delay"])+'s', id = log_id)
time.sleep(CONFIG["control"]["update_statement_delay"])

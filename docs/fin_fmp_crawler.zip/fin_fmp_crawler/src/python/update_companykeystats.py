#!/usr/bin/env python

"""
File: update_companykeystats.py
Author: Wolfgang Fuerst
Date: 2024-02-11
Description: ...
Runtime: ...
"""

import datetime
import time
from mylib import config
from mylib import writeLog
from mylib import fmp_service
from mylib import fmp_db

# load config file
CONFIG = config.load_config('config.json')["fmp"]

# log entry
writeLog(CONFIG["file"]["log"], 'Start Update Company Key List', id = 'UCK')

# set configuration
fmp_service.set_configuration(\
    api_key = CONFIG["connection"]["api_key"],
    speed = CONFIG["connection"]["speed"],
    file_speed_control = CONFIG["file"]["speed_control"],
    debug = CONFIG["debug"],
    file_debug = CONFIG["file"]["debug"]
    )

fmp_db.set_configuration(\
    host = CONFIG["database"]["host"],
    port = CONFIG["database"]["port"],
    schema = CONFIG["database"]["schema"],
    user = CONFIG["database"]["user"],
    password = CONFIG["database"]["password"]
    )

# get data data database
sql_engine = fmp_db.create_sql_engine(fmp_db.get_configuration())
connection = sql_engine.connect()
COMPANY_KEY_STATS = fmp_db.get_metatable(sql_engine, \
                                         CONFIG["database"]["tables"]["companykeystats"])
data = fmp_db.get_mysql_data(connection, COMPANY_KEY_STATS, columns = ["symbol", "updated"])
data = data[(data['updated'] < (datetime.datetime.now() - datetime.timedelta(days = 1)))]
print(len(data))
for index, row in data.iterrows():
    symbol = str(row['symbol']) # avoid 'None' finding errors
    print(symbol)
    # try query and try store data
    try:
        data_set = fmp_service.get_fmp_single_symbol_data("profile", symbol)
        try:
            fmp_db.put_dict_to_mysql(connection = connection, table = COMPANY_KEY_STATS, \
                                    data_dict = data_set, unique_keys=['symbol'])
        except: # pylint: disable=bare-except
            writeLog(CONFIG["file"]["log"], ''+symbol+' not stored', id = 'UCK')
    except: # pylint: disable=bare-except
        writeLog(CONFIG["file"]["log"], ''+symbol+' not found', id = 'UCK')            
connection.close()

# log entry
writeLog(CONFIG["file"]["log"], 'End Update Company Key List', id = 'UCK')

writeLog(CONFIG["file"]["log"], 'Wait Update Company Key List for '\
         +str(CONFIG["control"]["update_companykeystats_delay"])+'s', id = 'UCK')
time.sleep(CONFIG["control"]["update_companykeystats_delay"])

/*
2024-08-03
*/

CREATE TABLE `raw_fun` (
  `date` date NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `calendarYear` varchar(4) NOT NULL,
  `period` varchar(2) NOT NULL,
  `is_grossProfitRatio` double DEFAULT NULL,
  `is_netIncome` bigint DEFAULT NULL,
  `is_weightedAverageShsOut` bigint DEFAULT NULL,
  `cs_dividendsPaid` bigint DEFAULT NULL,
  `cs_operatingCashFlow` bigint DEFAULT NULL,
  `bs_totalStockholdersEquity` bigint DEFAULT NULL,
  `bs_preferredStock` bigint DEFAULT NULL,
  `is_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cs_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bs_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `eps` double GENERATED ALWAYS AS (if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)) STORED COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)\n',
  `dps` double GENERATED ALWAYS AS (if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-(`cs_dividendsPaid`) / `is_weightedAverageShsOut`),NULL)) STORED COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\\n\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\\n\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\\n\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)',
  `cps` double GENERATED ALWAYS AS (if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)) STORED COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\\\\n\\n\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\\\\n\\n\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\\\\n\\n\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)',
  `bps` double GENERATED ALWAYS AS (if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity` - `bs_preferredStock`) / `is_weightedAverageShsOut`),NULL)) STORED COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\\\\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\\\\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\\\\n\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)',
  PRIMARY KEY (`date`,`symbol`,`currency`,`calendarYear`,`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE DEFINER=`root`@`%` TRIGGER `raw_fun_AFTER_INSERT` AFTER INSERT ON `raw_fun` FOR EACH ROW BEGIN
	IF new.`currency` = 'EUR' THEN
		SET @fx = 1;
	ELSE
		IF new.`currency` = BINARY 'GBp' THEN
			SET @fx = (SELECT `close`*100 FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
		ELSEIF new.`currency` <> BINARY 'GBp' THEN 
			SET @fx = (SELECT `close` FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
		END IF;
	END IF;
	IF @fx IS NOT NULL THEN
        INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `grossProfitRatio`, `eps`, `dps`, `cps`, `bps`, `currency`, `updated`)
        VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`is_grossProfitRatio`, new.`eps`/@fx, new.`dps`/@fx, new.`cps`/@fx, new.`bps`/@fx, 'EUR', GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`))
        ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `eps` = new.`eps`/@fx, `dps` = new.`dps`/@fx, `cps` = new.`cps`/@fx, `bps` = new.`bps`/@fx, `currency` = 'EUR', `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);
    ELSE
        INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `grossProfitRatio`, `currency`, `updated`)
        VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`is_grossProfitRatio`, new.`currency`, GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`))
        ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `grossProfitRatio` = new.`is_grossProfitRatio`, `currency` = new.`currency`, `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);        
    END IF;
END

CREATE DEFINER=`root`@`%` TRIGGER `raw_fun_AFTER_UPDATE` AFTER UPDATE ON `raw_fun` FOR EACH ROW BEGIN
    IF (OLD.`is_updated` <> NEW.`is_updated`) OR (OLD.`cs_updated` <> NEW.`cs_updated`) OR (OLD.`bs_updated` <> NEW.`bs_updated`) THEN
		IF new.`currency` = 'EUR' THEN
			SET @fx = 1;
		ELSE
			IF new.`currency` = BINARY 'GBp' THEN
				SET @fx = (SELECT `close`*100 FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
			ELSEIF new.`currency` <> BINARY 'GBp' THEN 
				SET @fx = (SELECT `close` FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
			END IF;
		END IF;
		IF @fx IS NOT NULL THEN
			INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `grossProfitRatio`, `eps`, `dps`, `cps`, `bps`, `currency`, `updated`)
			VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`is_grossProfitRatio`, new.`eps`/@fx, new.`dps`/@fx, new.`cps`/@fx, new.`bps`/@fx, 'EUR', GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`))
			ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `eps` = new.`eps`/@fx, `dps` = new.`dps`/@fx, `cps` = new.`cps`/@fx, `bps` = new.`bps`/@fx, `currency` = 'EUR', `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);
		ELSE
			INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `grossProfitRatio`, `currency`, `updated`)
			VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`is_grossProfitRatio`, new.`currency`, GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`))
			ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `grossProfitRatio` = new.`is_grossProfitRatio`, `currency` = new.`currency`, `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);        
		END IF;   
    END IF;
END
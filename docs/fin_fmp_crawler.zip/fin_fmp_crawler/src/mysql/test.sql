CREATE DEFINER=`root`@`localhost` PROCEDURE `update_edcbps_eur_with_fx_eur`()
BEGIN
	/* update with new elements - incomestatement guides, because without outstanding shares you cannot calculate any x-per share */

	INSERT INTO fmp.eur_edcbps (`date`, `symbol`, `reportedCurrency`, `calendarYear`, `period`, `eps`, `dps`, `cps`, `bps`) SELECT * FROM (
		SELECT a.`date`, a.`symbol`, a.`reportedCurrency`, a.`calendarYear`, a.`period`, 
		(a.`netIncome` / a.`weightedAverageShsOut`) as `eps`,
		(-(b.`dividendsPaid`) / a.`weightedAverageShsOut`) AS `dps`,
		(b.`operatingCashFlow` / a.`weightedAverageShsOut`) AS `cps`,
		((c.`totalStockholdersEquity` - c.`preferredStock`) / a.`weightedAverageShsOut`) AS `bps`
		FROM fmp.raw_fun_income a
		LEFT JOIN fmp.raw_fun_cashflow b
		ON a.`date` = b.`date` AND a.`symbol` = b.`symbol` AND a.`reportedCurrency` = b.`reportedCurrency`
		LEFT JOIN fmp.raw_fun_balance c
		ON a.`date` = c.`date` AND a.`symbol` = c.`symbol` AND a.`reportedCurrency` = c.`reportedCurrency`
		WHERE a.`weightedAverageShsOut` <> 0
	) c
	on duplicate key update `calendarYear` = c.`calendarYear`, `period` = c.`period`, `eps` = c.`eps`, `dps` = c.`dps`, `cps` = c.`cps`, `bps` = c.`bps`;

	# ---

	/* update `close` with 1 where currency = 'EUR' */
	UPDATE fmp.eur_edcbps
	SET fmp.eur_edcbps.`fx_close` = 1
	WHERE fmp.eur_edcbps.`reportedCurrency` = 'EUR';


	/* update `close` with `close` from fx_eur */
	UPDATE fmp.eur_edcbps
	SET fmp.eur_edcbps.`fx_close` = (
		SELECT fmp.eur_ts_fx.`close` FROM fmp.eur_ts_fx
		WHERE fmp.eur_ts_fx.`date` = fmp.eur_edcbps.`date` AND  fmp.eur_ts_fx.`symbol` = fmp.eur_edcbps.`reportedCurrency`
	)
	WHERE fmp.eur_edcbps.`fx_close` IS NULL;

	/* update `close` with `close` from fx_eur -1 day (day before if no fx) */
	UPDATE fmp.eur_edcbps
	SET fmp.eur_edcbps.`fx_close` = (
		SELECT fmp.eur_ts_fx.`close` FROM fmp.eur_ts_fx
		WHERE fmp.eur_ts_fx.`date` = date_add(fmp.eur_edcbps.`date`, interval -1 day) AND  fmp.eur_ts_fx.`symbol` = fmp.eur_edcbps.`reportedCurrency`
	)
	WHERE fmp.eur_edcbps.`fx_close` IS NULL;

	/* update `close` with `close` from fx_eur -2 day (another day before if no fx)  */
	UPDATE fmp.eur_edcbps
	SET fmp.eur_edcbps.`fx_close` = (
		SELECT fmp.eur_ts_fx.`close` FROM fmp.eur_ts_fx
		WHERE fmp.eur_ts_fx.`date` = date_add(fmp.eur_edcbps.`date`, interval -2 day) AND  fmp.eur_ts_fx.`symbol` = fmp.eur_edcbps.`reportedCurrency`
	)
	WHERE fmp.eur_edcbps.`fx_close` IS NULL;
    
	INSERT INTO _function_log (`function`, `last_execution_time`)
	VALUES ('update_edcbps_eur_with_fx_eur', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();
END
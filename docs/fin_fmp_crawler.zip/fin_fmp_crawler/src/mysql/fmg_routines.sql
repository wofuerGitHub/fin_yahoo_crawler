-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: fmg
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'fmg'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `evt_recreate_edcbps_eur_overview_from_edcbps_eur` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`wolfgang`@`localhost`*/ /*!50106 EVENT `evt_recreate_edcbps_eur_overview_from_edcbps_eur` ON SCHEDULE EVERY 1 HOUR STARTS '2020-04-15 06:00:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL recreate_edcbps_eur_overview_from_edcbps_eur() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `evt_update_companykeystats_with_new_symbolslist_items` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`wolfgang`@`localhost`*/ /*!50106 EVENT `evt_update_companykeystats_with_new_symbolslist_items` ON SCHEDULE EVERY 1 HOUR STARTS '2020-04-15 06:15:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL update_companykeystats_with_new_symbolslist_items() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `evt_update_edcbps_eur_with_fx_eur` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`wolfgang`@`localhost`*/ /*!50106 EVENT `evt_update_edcbps_eur_with_fx_eur` ON SCHEDULE EVERY 1 HOUR STARTS '2020-04-15 06:30:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL update_edcbps_eur_with_fx_eur() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `evt_update_overview_eur_with_companykeystats_and_fx_eur` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`wolfgang`@`localhost`*/ /*!50106 EVENT `evt_update_overview_eur_with_companykeystats_and_fx_eur` ON SCHEDULE EVERY 1 HOUR STARTS '2020-04-15 06:45:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL update_overview_eur_with_companykeystats_and_fx_eur() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'fmg'
--
/*!50003 DROP PROCEDURE IF EXISTS `analyze_fx` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `analyze_fx`()
BEGIN
SELECT `symbol`, count(*) as `count`, min(`date`) as `min_date`, max(`date`) as `max_date`, datediff(max(`date`),min(`date`)) as `days`, count(*)/datediff(max(`date`),min(`date`)) as `coverage` FROM fmg.fx_eur group by `symbol` order by `count` desc;

	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('analyze_fx', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `find_dataset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `find_dataset`(IN item varchar(255))
BEGIN
	/*
	find symbol based on symbol, isin, company name or fragments of it
	*/
	DECLARE n INT DEFAULT 0;
	DECLARE i INT DEFAULT 0;

	SET @searchItem = concat('%',item,'%');
    
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp;
    CREATE TEMPORARY TABLE fmg.tmp
    SELECT DISTINCT b.symbol, format(b.price_eur,3) as `price`, format(b.min_eur,3) as `min`, format(b.max_eur,3) as `max`, format(b.lastDiv_eur,3) as `lastDiv`, format(b.mktCap_eur/1000000000,3) as `mktCap`, b.companyName, b.currency, b.isin, b.exchangeShortName, b.industry, b.sector, b.country, b.updated FROM fmg.overview_eur a 
    LEFT JOIN fmg.overview_eur b
    ON a.companyName = b.companyName
    WHERE a.companyName LIKE @searchItem OR a.isin LIKE @searchItem OR a.symbol LIKE @searchitem
	ORDER BY b.companyName ASC, b.isin ASC;

    SELECT a.*, b.`year`, b.`eps`, b.`dps`, b.`bps` FROM fmg.tmp a
    LEFT JOIN fmg.edcbps_eur_overview b
    ON a.symbol = b.symbol
    ORDER BY companyName ASC;
   
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp;
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp2;
    
	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('find_dataset', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_edcbps_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `get_edcbps_history`()
BEGIN
	DROP TEMPORARY TABLE IF EXISTS fmg.tmp;
	CREATE TEMPORARY TABLE fmg.tmp 
		SELECT a.symbol, a.symbol_fundamental, a.isin, b.date, b.eps_eur as `eps`, b.dps_eur as `dps`, b.cps_eur as `cps`, b.bps_eur as `bps` FROM fmg.referencedata a
		LEFT JOIN edcbps_eur b
		ON a.symbol_fundamental = b.symbol
        WHERE b.date is not null;
	
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp_1;
	CREATE TEMPORARY TABLE fmg.tmp_1
        SELECT a.symbol, a.date, b.close from tmp a 
		LEFT JOIN quote_eur b
		on DATE_ADD(a.date, INTERVAL 0 DAY) = b.date and a.symbol = b.symbol;
	
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp_2;
	CREATE TEMPORARY TABLE fmg.tmp_2
        SELECT a.symbol, a.date, b.close from tmp_1 a 
		LEFT JOIN quote_eur b
		on DATE_ADD(a.date, INTERVAL -1 DAY) = b.date and a.symbol = b.symbol
        where a.close is null;
	
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp_3;
	CREATE TEMPORARY TABLE fmg.tmp_3
        SELECT a.symbol, a.date, b.close from tmp_2 a 
		LEFT JOIN quote_eur b
		on DATE_ADD(a.date, INTERVAL -2 DAY) = b.date and a.symbol = b.symbol
        where a.close is null;        
	
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp_4;
	CREATE TEMPORARY TABLE fmg.tmp_4
        SELECT a.symbol, a.date, b.close from tmp_3 a 
		LEFT JOIN quote_eur b
		on DATE_ADD(a.date, INTERVAL -3 DAY) = b.date and a.symbol = b.symbol
        where a.close is null;
	
    DROP TEMPORARY TABLE IF EXISTS fmg.tmp_5;
	CREATE TEMPORARY TABLE fmg.tmp_5
        SELECT a.symbol, a.date, b.close from tmp_4 a 
		LEFT JOIN quote_eur b
		on DATE_ADD(a.date, INTERVAL -4 DAY) = b.date and a.symbol = b.symbol
        where a.close is null;

	INSERT INTO fmg.function_log (`function`, `last_execution_time`)
	VALUES ('get_edcbps_history', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();
	
    SELECT b.*, a.close FROM (
		SELECT * FROM fmg.tmp_1 where close is not null
		UNION
		SELECT * FROM fmg.tmp_2 where close is not null
		UNION
		SELECT * FROM fmg.tmp_3 where close is not null
		UNION
		SELECT * FROM fmg.tmp_4 where close is not null
		UNION
		SELECT * FROM fmg.tmp_5 where close is not null) a
	LEFT JOIN fmg.tmp b
	ON a.symbol = b.symbol and a.date = b.date
    WHERE a.`date` >= (CURDATE() - INTERVAL 7 YEAR);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `recreate_edcbps_eur_overview_from_edcbps_eur` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `recreate_edcbps_eur_overview_from_edcbps_eur`()
BEGIN
	DROP TABLE IF EXISTS fmg.edcbps_eur_overview;
	CREATE TABLE `edcbps_eur_overview` (
		`symbol` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
		`year` text,
		`eps` text,
        `dps` text,
		`bps` text,
		`updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY (`symbol`),
		UNIQUE KEY `symbol_UNIQUE` (`symbol`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci	
    SELECT symbol, group_concat(`calendarYear` order by `calendarYear` desc) as `year`, 
		group_concat(FORMAT(`eps_eur`,1) order by `calendarYear` desc) as `eps`, 
        group_concat(FORMAT(`dps_eur`,1) order by `calendarYear` desc) as `dps`,
		group_concat(FORMAT(`bps_eur`,1) order by `calendarYear` desc) as `bps` FROM edcbps_eur
		group by symbol;

	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('recreate_edcbps_eur_overview_from_edcbps_eur', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_companykeystats_with_new_symbolslist_items` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `update_companykeystats_with_new_symbolslist_items`()
BEGIN
	/*
	update companykeystats with new symbols from symbolslist
	*/
	INSERT INTO fmg.companykeystats (symbol) SELECT a.symbol FROM fmg.symbolslist a
	LEFT JOIN fmg.companykeystats b
	ON a.symbol = b.symbol
	WHERE b.symbol IS NULL;
    
	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('update_companykeystats_with_new_symbolslist_items', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_edcbps_eur_with_fx_eur` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `update_edcbps_eur_with_fx_eur`()
BEGIN
	/* update with new elements - incomestatement guides, because without outstanding shares you cannot calculate any x-per share */

	INSERT INTO fmg.edcbps_eur (`date`, `symbol`, `reportedCurrency`, `calendarYear`, `period`, `eps`, `dps`, `cps`, `bps`) SELECT * FROM (
		SELECT a.`date`, a.`symbol`, a.`reportedCurrency`, a.`calendarYear`, a.`period`, 
		(a.`netIncome` / a.`weightedAverageShsOut`) as `eps`,
		(-(b.`dividendsPaid`) / a.`weightedAverageShsOut`) AS `dps`,
		(b.`operatingCashFlow` / a.`weightedAverageShsOut`) AS `cps`,
		((c.`totalStockholdersEquity` - c.`preferredStock`) / a.`weightedAverageShsOut`) AS `bps`
		FROM fmg.incomestatement a
		LEFT JOIN fmg.cashflowstatement b
		ON a.`date` = b.`date` AND a.`symbol` = b.`symbol` AND a.`reportedCurrency` = b.`reportedCurrency`
		LEFT JOIN fmg.balancesheetstatement c
		ON a.`date` = c.`date` AND a.`symbol` = c.`symbol` AND a.`reportedCurrency` = c.`reportedCurrency`
		WHERE a.`weightedAverageShsOut` <> 0
	) c
	on duplicate key update `calendarYear` = c.`calendarYear`, `period` = c.`period`, `eps` = c.`eps`, `dps` = c.`dps`, `cps` = c.`cps`, `bps` = c.`bps`;

	# ---

	/* update `close` with 1 where currency = 'EUR' */
	UPDATE fmg.edcbps_eur
	SET fmg.edcbps_eur.`fx_close` = 1
	WHERE fmg.edcbps_eur.`reportedCurrency` = 'EUR';


	/* update `close` with `close` from fx_eur */
	UPDATE fmg.edcbps_eur
	SET fmg.edcbps_eur.`fx_close` = (
		SELECT fmg.fx_eur.`close` FROM fmg.fx_eur
		WHERE fmg.fx_eur.`date` = fmg.edcbps_eur.`date` AND  fmg.fx_eur.`symbol` = fmg.edcbps_eur.`reportedCurrency`
	)
	WHERE fmg.edcbps_eur.`fx_close` IS NULL;

	/* update `close` with `close` from fx_eur -1 day (day before if no fx) */
	UPDATE fmg.edcbps_eur
	SET fmg.edcbps_eur.`fx_close` = (
		SELECT fmg.fx_eur.`close` FROM fmg.fx_eur
		WHERE fmg.fx_eur.`date` = date_add(fmg.edcbps_eur.`date`, interval -1 day) AND  fmg.fx_eur.`symbol` = fmg.edcbps_eur.`reportedCurrency`
	)
	WHERE fmg.edcbps_eur.`fx_close` IS NULL;

	/* update `close` with `close` from fx_eur -2 day (another day before if no fx)  */
	UPDATE fmg.edcbps_eur
	SET fmg.edcbps_eur.`fx_close` = (
		SELECT fmg.fx_eur.`close` FROM fmg.fx_eur
		WHERE fmg.fx_eur.`date` = date_add(fmg.edcbps_eur.`date`, interval -2 day) AND  fmg.fx_eur.`symbol` = fmg.edcbps_eur.`reportedCurrency`
	)
	WHERE fmg.edcbps_eur.`fx_close` IS NULL;
    
	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('update_edcbps_eur_with_fx_eur', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_overview_eur_with_companykeystats_and_fx_eur` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `update_overview_eur_with_companykeystats_and_fx_eur`()
BEGIN

DROP temporary TABLE IF EXISTS fmg.tmp;
CREATE temporary TABLE fmg.tmp
SELECT b.`close`, c.* FROM (
	SELECT `symbol`, max(`date`) as `date` FROM fmg.fx_eur group by `symbol`) a
LEFT JOIN fmg.fx_eur b
ON a.`symbol` = b.`symbol` AND a.`date` = b.`date`
RIGHT JOIN fmg.companykeystats c
ON a.`symbol` = c.`currency`;

INSERT INTO fmg.overview_eur (`symbol`, `companyName`, `currency`, `isin`, `exchangeShortName`, `industry`, `sector`, `country`, `updated`, `price`, `min`, `max`, `range`, `lastDiv`, `mktCap`, `fx_close`)
SELECT b.`symbol`, b.`companyName`, b.`currency`, b.`isin`, b.`exchangeShortName`, b.`industry`, b.`sector`, b.`country`, b.`updated`, b.`price`, 
IF(SUBSTRING_INDEX(b.range,'-', 1) REGEXP '^[0-9\.]+$', SUBSTRING_INDEX(b.range,'-', 1), NULL) as `min`, 
IF(SUBSTRING_INDEX(b.range,'-', -1) REGEXP '^[0-9\.]+$', SUBSTRING_INDEX(b.range,'-', -1), NULL) as `max`, 
b.`range`, b.`lastDiv`, b.`mktCap`, b.`close` FROM fmg.tmp b
ON DUPLICATE KEY UPDATE `companyName` = b.`companyName`, `currency` = b.`currency`, `isin` = b.`isin`, `exchangeShortName` = b.`exchangeShortName`, 
`industry` = b.`industry`, `sector` = b.`sector`, `country` = b.`country`, `updated` = b.`updated`, `price` = b.`price`, `min` = IF(SUBSTRING_INDEX(b.range,'-', 1) REGEXP '^[0-9\.]+$', SUBSTRING_INDEX(b.range,'-', 1), NULL), 
`max` = IF(SUBSTRING_INDEX(b.range,'-', -1) REGEXP '^[0-9\.]+$', SUBSTRING_INDEX(b.range,'-', -1), NULL), `range` = b.`range`,  `lastDiv` = b.`lastDiv`, `mktCap` = b.`mktCap`, `fx_close` = b.`close`;

DROP temporary Table IF EXISTS fmg.tmp;

UPDATE fmg.overview_eur SET fmg.overview_eur.`fx_close` = fmg.overview_eur.`fx_close`*100 WHERE fmg.overview_eur.`currency` = 'GBp';
UPDATE fmg.overview_eur SET fmg.overview_eur.`fx_close` = 1 WHERE fmg.overview_eur.`currency` = 'EUR';

	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('update_overview_eur_with_companykeystats_and_fx_eur', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_referencedata_with_companykeystats` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`wolfgang`@`localhost` PROCEDURE `update_referencedata_with_companykeystats`()
BEGIN
	/*
    update fmg.referencedata where companyName, industry, sector or country is NULL with data from companykeystats
    */
	UPDATE fmg.referencedata a
	INNER JOIN fmg.companykeystats b ON (a.symbol = b.symbol)
	SET a.companyName = b.companyName
	WHERE a.companyName IS NULL;
    
	UPDATE fmg.referencedata a
	INNER JOIN fmg.companykeystats b ON (a.symbol = b.symbol)
	SET a.industry = b.industry
	WHERE a.industry IS NULL;
    
	UPDATE fmg.referencedata a
	INNER JOIN fmg.companykeystats b ON (a.symbol = b.symbol)
	SET a.sector = b.sector
	WHERE a.sector IS NULL;
    
	UPDATE fmg.referencedata a
	INNER JOIN fmg.companykeystats b ON (a.symbol = b.symbol)
	SET a.country = b.country
	WHERE a.country IS NULL;
    /*
    set symbol_fundamental to symbol on NULL and if edcbps_eur delivers
    */
    UPDATE fmg.referencedata d,
    (
		SELECT a.symbol FROM fmg.referencedata a
		LEFT JOIN edcbps_eur_overview b
		ON a.symbol = b.symbol
		WHERE a.symbol_fundamental IS NULL and b.symbol IS NOT NULL
        ) c
	SET d.symbol_fundamental = d.symbol
	WHERE d.symbol = c.symbol;
    
    	INSERT INTO function_log (`function`, `last_execution_time`)
	VALUES ('update_referencedata_with_companykeystats', now())
	ON DUPLICATE KEY UPDATE `last_execution_time` = now();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-12 18:03:18

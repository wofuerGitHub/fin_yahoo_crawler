-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: fmg
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `incomestatement`
--

DROP TABLE IF EXISTS `incomestatement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomestatement` (
  `date` date NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `reportedCurrency` varchar(3) NOT NULL,
  `cik` text,
  `fillingDate` text,
  `acceptedDate` text,
  `calendarYear` text,
  `period` text,
  `revenue` bigint DEFAULT NULL,
  `costOfRevenue` bigint DEFAULT NULL,
  `grossProfit` bigint DEFAULT NULL,
  `grossProfitRatio` double DEFAULT NULL,
  `researchAndDevelopmentExpenses` bigint DEFAULT NULL,
  `generalAndAdministrativeExpenses` double DEFAULT NULL,
  `sellingAndMarketingExpenses` double DEFAULT NULL,
  `sellingGeneralAndAdministrativeExpenses` bigint DEFAULT NULL,
  `otherExpenses` double DEFAULT NULL,
  `operatingExpenses` bigint DEFAULT NULL,
  `costAndExpenses` bigint DEFAULT NULL,
  `interestIncome` bigint DEFAULT NULL,
  `interestExpense` double DEFAULT NULL,
  `depreciationAndAmortization` bigint DEFAULT NULL,
  `ebitda` bigint DEFAULT NULL,
  `ebitdaratio` double DEFAULT NULL,
  `operatingIncome` bigint DEFAULT NULL,
  `operatingIncomeRatio` double DEFAULT NULL,
  `totalOtherIncomeExpensesNet` bigint DEFAULT NULL,
  `incomeBeforeTax` bigint DEFAULT NULL,
  `incomeBeforeTaxRatio` double DEFAULT NULL,
  `incomeTaxExpense` bigint DEFAULT NULL,
  `netIncome` bigint DEFAULT NULL,
  `netIncomeRatio` double DEFAULT NULL,
  `eps` double DEFAULT NULL,
  `epsdiluted` double DEFAULT NULL,
  `weightedAverageShsOut` bigint DEFAULT NULL,
  `weightedAverageShsOutDil` bigint DEFAULT NULL,
  `link` text,
  `finalLink` text,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`date` DESC,`symbol`,`reportedCurrency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-12 18:02:26

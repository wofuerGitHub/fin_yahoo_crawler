AFTER INSERT

CREATE DEFINER=`root`@`%` TRIGGER `raw_ts_quote_eps_AFTER_INSERT` AFTER INSERT ON `raw_ts_quote_eps` FOR EACH ROW BEGIN
	IF new.`currency` = 'EUR' THEN
		SET @fx = 1;
	ELSE
		IF new.`currency` = BINARY 'GBp' THEN
			SET @fx = (SELECT `close`*100 FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
		ELSEIF new.`currency` <> BINARY 'GBp' THEN 
			SET @fx = (SELECT `close` FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
		END IF;
	END IF;
	IF @fx IS NOT NULL THEN
		INSERT INTO `fmp`.`eur_ts_quote` (`date`, `symbol`, `open`, `high`, `low`, `close`, `per`, `currency`, `updated`)
		VALUES (new.`date`, new.`symbol`,  new.`open`/@fx, new.`high`/@fx, new.`low`/@fx, new.`close`/@fx, new.`per`, 'EUR', new.`updated`)
		ON DUPLICATE KEY UPDATE `open`= new.`open`/@fx, `high` = new.`high`/@fx, `low` = new.`low`/@fx, `close` = new.`close`/@fx, `per` = new.`per`, `updated` = new.`updated`;
    END IF;
END

---

AFTER UPDATE

CREATE DEFINER=`root`@`%` TRIGGER `raw_ts_quote_eps_AFTER_UPDATE` AFTER UPDATE ON `raw_ts_quote_eps` FOR EACH ROW BEGIN
    IF OLD.`updated` <> NEW.`updated` THEN
		IF new.`currency` = 'EUR' THEN
			SET @fx = 1;
		ELSE
			IF new.`currency` = BINARY 'GBp' THEN
				SET @fx = (SELECT `close`*100 FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
			ELSEIF new.`currency` <> BINARY 'GBp' THEN 
				SET @fx = (SELECT `close` FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
			END IF;
		END IF;
		IF @fx IS NOT NULL THEN
			INSERT INTO `fmp`.`eur_ts_quote` (`date`, `symbol`, `open`, `high`, `low`, `close`, `per`, `currency`, `updated`)
			VALUES (new.`date`, new.`symbol`,  new.`open`/@fx, new.`high`/@fx, new.`low`/@fx, new.`close`/@fx, new.`per`, 'EUR', new.`updated`)
			ON DUPLICATE KEY UPDATE `open`= new.`open`/@fx, `high` = new.`high`/@fx, `low` = new.`low`/@fx, `close` = new.`close`/@fx, `per` = new.`per`, `updated` = new.`updated`;
		END IF;        
    END IF;
END
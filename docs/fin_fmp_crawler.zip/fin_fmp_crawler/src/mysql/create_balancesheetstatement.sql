-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: fmg
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balancesheetstatement`
--

DROP TABLE IF EXISTS `balancesheetstatement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balancesheetstatement` (
  `date` date NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `reportedCurrency` varchar(3) NOT NULL,
  `cik` text,
  `fillingDate` text,
  `acceptedDate` text,
  `calendarYear` text,
  `period` text,
  `cashAndCashEquivalents` bigint DEFAULT NULL,
  `shortTermInvestments` bigint DEFAULT NULL,
  `cashAndShortTermInvestments` bigint DEFAULT NULL,
  `netReceivables` bigint DEFAULT NULL,
  `inventory` bigint DEFAULT NULL,
  `otherCurrentAssets` bigint DEFAULT NULL,
  `totalCurrentAssets` bigint DEFAULT NULL,
  `propertyPlantEquipmentNet` bigint DEFAULT NULL,
  `goodwill` double DEFAULT NULL,
  `intangibleAssets` double DEFAULT NULL,
  `goodwillAndIntangibleAssets` double DEFAULT NULL,
  `longTermInvestments` bigint DEFAULT NULL,
  `taxAssets` double DEFAULT NULL,
  `otherNonCurrentAssets` bigint DEFAULT NULL,
  `totalNonCurrentAssets` bigint DEFAULT NULL,
  `otherAssets` double DEFAULT NULL,
  `totalAssets` bigint DEFAULT NULL,
  `accountPayables` bigint DEFAULT NULL,
  `shortTermDebt` double DEFAULT NULL,
  `taxPayables` double DEFAULT NULL,
  `deferredRevenue` bigint DEFAULT NULL,
  `otherCurrentLiabilities` bigint DEFAULT NULL,
  `totalCurrentLiabilities` bigint DEFAULT NULL,
  `longTermDebt` double DEFAULT NULL,
  `deferredRevenueNonCurrent` double DEFAULT NULL,
  `deferredTaxLiabilitiesNonCurrent` double DEFAULT NULL,
  `otherNonCurrentLiabilities` bigint DEFAULT NULL,
  `totalNonCurrentLiabilities` bigint DEFAULT NULL,
  `otherLiabilities` double DEFAULT NULL,
  `capitalLeaseObligations` double DEFAULT NULL,
  `totalLiabilities` bigint DEFAULT NULL,
  `preferredStock` double DEFAULT NULL,
  `commonStock` bigint DEFAULT NULL,
  `retainedEarnings` bigint DEFAULT NULL,
  `accumulatedOtherComprehensiveIncomeLoss` bigint DEFAULT NULL,
  `othertotalStockholdersEquity` double DEFAULT NULL,
  `totalStockholdersEquity` bigint DEFAULT NULL,
  `totalLiabilitiesAndStockholdersEquity` bigint DEFAULT NULL,
  `minorityInterest` bigint DEFAULT NULL,
  `totalEquity` bigint DEFAULT NULL,
  `totalLiabilitiesAndTotalEquity` bigint DEFAULT NULL,
  `totalInvestments` bigint DEFAULT NULL,
  `totalDebt` double DEFAULT NULL,
  `netDebt` bigint DEFAULT NULL,
  `link` text,
  `finalLink` text,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`date` DESC,`symbol`,`reportedCurrency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-12 18:02:36

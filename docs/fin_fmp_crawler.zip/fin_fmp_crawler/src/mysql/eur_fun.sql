CREATE TABLE `eur_fun` (
  `date` date NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `calendarYear` text NOT NULL,
  `period` text NOT NULL,
  `grossProfitRatio` double DEFAULT NULL,
  `eps` double DEFAULT NULL COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)\n',
  `dps` double DEFAULT NULL COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\\n\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\\n\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\\n\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)',
  `cps` double DEFAULT NULL COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\\\\n\\n\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\\\\n\\n\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\\\\n\\n\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)',
  `bps` double DEFAULT NULL COMMENT 'eps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`is_netIncome` / `is_weightedAverageShsOut`),NULL)\\\\ndps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(-`cs_dividendsPaid` / `is_weightedAverageShsOut`),NULL)\\\\ncps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),(`cs_operatingCashFlow` / `is_weightedAverageShsOut`),NULL)\\\\n\nbps: if(((`is_weightedAverageShsOut` is not null) and (`is_weightedAverageShsOut` >= 1)),((`bs_totalStockholdersEquity`-bs_preferredStock) / `is_weightedAverageShsOut`),NULL)',
  `currency` varchar(3) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `manual` text,
  PRIMARY KEY (`date`,`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

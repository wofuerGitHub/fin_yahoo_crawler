AFTER INSERT

CREATE DEFINER=`root`@`%` TRIGGER `raw_fun_AFTER_INSERT` AFTER INSERT ON `raw_fun` FOR EACH ROW BEGIN
	IF new.`currency` = 'EUR' THEN
		SET @fx = 1;
	ELSE
		IF new.`currency` = BINARY 'GBp' THEN
			SET @fx = (SELECT `close`*100 FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
		ELSEIF new.`currency` <> BINARY 'GBp' THEN 
			SET @fx = (SELECT `close` FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
		END IF;
	END IF;
	IF @fx IS NOT NULL THEN
        INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `eps`, `dps`, `cps`, `bps`, `currency`, `updated`)
        VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`eps`/@fx, new.`dps`/@fx, new.`cps`/@fx, new.`bps`/@fx, 'EUR', GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`)
        ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `eps` = new.`eps`/@fx, `dps` = new.`dps`/@fx, `cps` = new.`cps`/@fx, `bps` = new.`bps`/@fx, `currency` = 'EUR', `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);
    ELSEIF @fx IS NULL THEN
        INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `currency`, `updated`)
        VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`currency`, GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`)
        ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `currency` = new.`currency`, `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);        
    END IF;
END

---

AFTER UPDATE

CREATE DEFINER=`root`@`%` TRIGGER `raw_fun_AFTER_UPDATE` AFTER UPDATE ON `raw_fun` FOR EACH ROW BEGIN
    IF OLD.`is_updated` <> NEW.`is_updated` OR OLD.`cs_updated` <> NEW.`cs_updated` OR OLD.`bs_updated` <> NEW.`bs_updated` THEN
        IF new.`currency` = 'EUR' THEN
            SET @fx = 1;
        ELSE
            IF new.`currency` = BINARY 'GBp' THEN
                SET @fx = (SELECT `close`*100 FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
            ELSEIF new.`currency` <> BINARY 'GBp' THEN 
                SET @fx = (SELECT `close` FROM `fmp`.`eur_ts_fx` WHERE `symbol` = new.`currency` AND `date` = new.`date`);
            END IF;
        END IF;
        IF @fx IS NOT NULL THEN
            INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `eps`, `dps`, `cps`, `bps`, `currency`, `updated`)
            VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`eps`/@fx, new.`dps`/@fx, new.`cps`/@fx, new.`bps`/@fx, 'EUR', GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`)
            ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `eps` = new.`eps`/@fx, `dps` = new.`dps`/@fx, `cps` = new.`cps`/@fx, `bps` = new.`bps`/@fx, `currency` = 'EUR', `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);
        ELSEIF @fx IS NULL THEN
            INSERT INTO `fmp`.`eur_fun` (`date`, `symbol`, `calendarYear`, `period`, `currency`, `updated`)
            VALUES (new.`date`, new.`symbol`, new.`calendarYear`, new.`period`, new.`currency`, GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`)
            ON DUPLICATE KEY UPDATE `calendarYear` = new.`calendarYear`, `period` = new.`period`, `currency` = new.`currency`, `updated` = GREATEST(new.`is_updated`, new.`cs_updated`, new.`bs_updated`);        
        END IF;      
    END IF;
END
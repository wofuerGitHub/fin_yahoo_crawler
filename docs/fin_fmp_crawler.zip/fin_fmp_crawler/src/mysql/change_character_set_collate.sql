alter table fmp.companykeystats convert to character set utf8mb4 collate utf8mb4_0900_ai_ci;

#!/bin/bash

docker run --rm -v fin_db_vol:/volume -v $(pwd)/backup:/backup \busybox tar cvf /fin_db_vol.tar -C /volume .

# FMP Crawler

FMP Crawler is a Python/MySQL ingestion pipeline for collecting market and company data from [Financial Modeling Prep (FMP)](https://site.financialmodelingprep.com/). It loads security master data, company profiles, annual financial statements, historical prices, current quotes, and EUR foreign-exchange rates into MySQL. Database-side transformations can then expose selected values in EUR for downstream investment analysis.

This repository contains the crawler workers and a collection of database artifacts. It does **not** expose an HTTP API or user interface.

## What it collects

- Stock and ETF symbol lists
- Company profiles and key statistics
- Income statements, balance sheets, and cash-flow statements
- Historical daily prices
- Current prices and EPS values
- EUR exchange-rate histories and current rates
- Derived EUR-denominated price and per-share data through MySQL tables and triggers

## Architecture

```mermaid
flowchart LR
    FMP[Financial Modeling Prep API] --> API[FMP client and shared rate control]
    API --> S[Symbol-list worker]
    API --> C[Company-profile worker]
    API --> F[Financial-statement workers]
    API --> T[Historical time-series worker]
    API --> Q[Current quote worker]

    S --> RAW[(MySQL raw tables)]
    C --> RAW
    F --> RAW
    T --> RAW
    Q --> RAW
    RAW --> DB[MySQL triggers and routines]
    DB --> EUR[(EUR-normalized tables)]
```

Each worker performs one update cycle, sleeps for the delay configured in `config.json`, and then exits. The Docker Compose deployment uses `restart: always`, so the container restarts and begins the next cycle. All FMP workers share a file-based rate limiter.

## Components

| Component | Entry point | Purpose |
| --- | --- | --- |
| Symbol list | `src/python/update_symbolslist.py` | Imports the FMP stock and ETF lists. |
| Company profiles | `src/python/update_companykeystats.py` | Refreshes profile rows whose `updated` value is older than one day. |
| Statements | `src/python/update_statement.py` | Imports annual income, cash-flow, or balance-sheet data. |
| Historical data | `src/python/update_timeserie.py` | Loads full histories when requested, then performs rolling 30-day updates for quotes and EUR FX rates. |
| Current data | `src/python/update_stream.py` | Refreshes rows marked for streaming in the reference tables. |
| Reference mapping | `src/python/insert_referencedata.py` | Interactive utility for pairing price and fundamental symbols. |
| FMP client | `src/python/mylib/fmp_service.py` | Calls FMP v3 endpoints and maps responses to database records. |
| Database access | `src/python/mylib/fmp_db.py` | Reflects MySQL tables and performs batched upserts with SQLAlchemy. |
| Yahoo client | `src/python/mylib/yahoo_service.py` | Experimental alternative quote source; it is not used by the crawler workers. |

`src/python/check_and_fix.py` is an unfinished diagnostic utility. It references a `check_and_fix_delay` setting that is not present in the current configuration and should not be treated as a scheduled worker.

## Prerequisites

- Python 3.9 (the version used by the Docker images)
- MySQL 8; the supplied database Compose file pins MySQL 8.0.35
- An FMP API key with access to the endpoints used by this project
- Docker Engine with Docker Compose v2, if using containers

API availability, historical depth, and request limits depend on the FMP subscription.

## Configuration

Every executable reads `config.json` from its **current working directory**. Update it before running a worker.

```json
{
  "fmp": {
    "database": {
      "host": "127.0.0.1",
      "port": "3310",
      "schema": "fmp",
      "user": "fmp",
      "password": "change-me",
      "tables": {
        "reference_fx": "_reference_fx",
        "reference_map": "_reference_map",
        "symbolslist": "raw_assetslist",
        "companykeystats": "raw_companykeystats",
        "income": "raw_fun_income",
        "cashflow": "raw_fun_cashflow",
        "balance": "raw_fun_balance",
        "fx": "raw_ts_fx",
        "quote": "raw_ts_quote",
        "quote_eps": "raw_ts_quote_eps"
      }
    },
    "connection": {
      "api_key": "YOUR_FMP_API_KEY",
      "speed": 10
    },
    "file": {
      "log": "./fmp_crawler.log",
      "debug": "./fmp_debug.log",
      "speed_control": "./fmp_speed.ctl"
    },
    "control": {
      "update_companykeystats_delay": 86400,
      "update_statement_delay": 86400,
      "update_statement_all": false,
      "update_stream_delay": 3600,
      "update_symbolslist_delay": 43200,
      "update_timeserie_delay": 10800
    },
    "debug": false
  }
}
```

Important settings:

- `connection.speed` is the intended combined number of FMP requests per minute. Containers must share the same `fmp_speed.ctl` file for this to work across workers.
- `control.*_delay` values are seconds slept after a worker finishes one cycle.
- `control.update_statement_all: false` limits statement imports to symbols in `_reference_map`; `true` processes every symbol in the company-profile table.
- File paths are relative to the directory from which the process starts.
- Table names are configurable but all referenced tables and columns must already exist.

### Security warning

`config.json` is currently a tracked plaintext file, and debug logging writes complete request URLs—including the FMP API key—to `fmp_debug.log`. Before using this project:

1. Rotate any credential that has previously been committed.
2. Replace the checked-in key and database password with your own values.
3. Keep `debug` set to `false` outside a controlled development environment.
4. Do not commit populated configuration or log files.

The application does not currently support environment-variable overrides or a secrets manager.

## Database setup

The database directory contains useful schema fragments, triggers, and routines, but it is **not a complete, ordered migration for a fresh installation**. In particular, the current `config.json` uses `raw_*`, `eur_*`, and `_reference_*` table names that are not all created by the checked-in scripts. Some older SQL files also refer to the former `fmg` schema and include environment-specific `DEFINER` clauses.

To start the supplied MySQL container:

```bash
docker network create default_network
docker volume create fmp_db_vol
docker compose -f src/docker/docker-compose_fmp_db.yml up -d
```

The container publishes MySQL at `127.0.0.1:3310` and uses the development root password declared in the Compose file. Create the base schema with:

```bash
mysql --host=127.0.0.1 --port=3310 --user=root --password \
  < src/mysql/create_schema.sql
```

You must then restore or create the complete application schema, including the tables named under `database.tables`, their expected columns, reference data, and the `fmp` database user. Treat the files in `src/mysql/` as implementation references and review them before applying them; do not run the entire directory blindly.

Key runtime prerequisites are:

- `_reference_fx` with `symbol`, `currency`, `longTimeSerie`, and `stream`
- `_reference_map` with `symbol`, `symbol_fundamental`, `currency`, `longTimeSerie`, and `stream`
- Raw target tables matching all names in `config.json`
- Unique keys matching those used by the upsert calls (for example, quote rows use `date` and `symbol`)
- Database transformations/triggers if EUR-normalized output is required

## Run locally

Create an environment and install the runtime dependencies:

```bash
python3.9 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
touch fmp_crawler.log fmp_debug.log fmp_speed.ctl
```

Run commands from the repository root so that `config.json` and the state files resolve correctly:

```bash
PYTHONPATH=src/python python src/python/update_symbolslist.py
PYTHONPATH=src/python python src/python/update_companykeystats.py

PYTHONPATH=src/python python src/python/update_statement.py income
PYTHONPATH=src/python python src/python/update_statement.py cashflow
PYTHONPATH=src/python python src/python/update_statement.py balance

PYTHONPATH=src/python python src/python/update_timeserie.py
PYTHONPATH=src/python python src/python/update_stream.py
```

The normal data-loading order is symbol list, company profiles, reference mappings, statements, historical data, and finally current quote updates. Database events or equivalent logic must populate the company-profile work list from the imported symbol list.

To maintain `_reference_map` interactively after the supporting `find_dataset` procedure has been installed:

```bash
PYTHONPATH=src/python python src/python/insert_referencedata.py
```

## Run with Docker

Build the five crawler images from the repository root:

```bash
docker build -f dockerfile_symbolslist -t fmp_crawler_symbolslist:latest .
docker build -f dockerfile_companykeystats -t fmp_crawler_companykeystats:latest .
docker build -f dockerfile_statement -t fmp_crawler_statement:latest .
docker build -f dockerfile_timeserie -t fmp_crawler_timeserie:latest .
docker build -f dockerfile_stream -t fmp_crawler_stream:latest .
```

Before starting the crawler Compose stack, edit `src/docker/docker-compose_fmp.yml`:

1. Replace its `/home/wolfgang/Documents/Coding/fmp_crawler/...` bind-mount sources with absolute paths to your checkout.
2. Make its networking consistent with the database configuration.

The checked-in application Compose file uses host networking. With that configuration, set the database address to `127.0.0.1:3310` and ensure host networking is supported and enabled by your Docker installation. The checked-in `config.json` currently uses port `3309`, which does not match the database Compose mapping and must be corrected. For a portable bridge-network setup, remove `network_mode: host`, attach the services to `default_network`, and use `fmp_db:3306` in `config.json`.

Create the mounted files and start the workers:

```bash
touch fmp_crawler.log fmp_debug.log fmp_speed.ctl
docker compose -f src/docker/docker-compose_fmp.yml up -d
docker compose -f src/docker/docker-compose_fmp.yml ps
```

Follow one worker or the shared application log with:

```bash
docker compose -f src/docker/docker-compose_fmp.yml logs -f fmp_stream
tail -f fmp_crawler.log
```

Stop the stack with:

```bash
docker compose -f src/docker/docker-compose_fmp.yml down
```

`docker_start_up.sh` is a host-specific deployment helper: it references pre-move Dockerfile paths and transfers images to a hard-coded remote machine. Review and update it before use.

## Tests

The current tests are integration tests, not isolated unit tests. They call live FMP/Yahoo services, use `config.json`, honor the rate-control delay, and may consume API quota. Several requests are also executed at module import time.

Install the test-only packages, which are not currently listed in `requirements.txt`:

```bash
python -m pip install pytest yfinance
```

Then run:

```bash
PYTHONPATH=src/python pytest -v src/python/test_fmp_service.py
PYTHONPATH=src/python pytest -v src/python/test_yahoo_service.py
```

Test results depend on network access, provider availability, market data, and the permissions of the configured FMP key. The Yahoo test currently calls `get_yahoo_quote` with an incompatible positional argument at import time, so it may fail before its test cases run.

## Repository layout

```text
.
├── config.json                  # Runtime configuration (currently tracked)
├── dockerfile_*                 # Worker image definitions
├── requirements.txt             # Core Python dependencies
├── src/
│   ├── docker/                  # MySQL and crawler Compose definitions
│   ├── mysql/                   # Partial/legacy DDL, triggers, and routines
│   └── python/
│       ├── mylib/               # API, configuration, logging, and DB helpers
│       ├── update_*.py          # Crawler workers
│       ├── insert_referencedata.py
│       └── test_*.py            # Live-service integration tests
└── documentation/               # ArchiMate model and operational notes
```

The current architecture model is available at `documentation/fmp-crawler-project-documentation.archimate` and can be opened with [Archi](https://www.archimatetool.com/).

## Operational notes

- Upserts update non-key columns and set `updated` to the database server's current timestamp.
- FMP errors can appear as empty payloads; inspect both console output and `fmp_crawler.log` when data is missing.
- The shared rate-control file has no file lock. Avoid starting duplicate stacks or extra workers against the same API key.
- `update_companykeystats.py` only processes existing company-profile rows; it does not create its own work list from the symbol table.
- A first historical load can make many requests because `longTimeSerie` rows are fetched backwards in 20-year windows.
- The checked-in company-profile and statement delays are `0`. With `restart: always`, their containers restart immediately after every cycle; configure non-zero delays for normal operation.
- The interactive reference-data loader currently passes numeric input to pandas as a string index and may require correction before use.

## Contributing

Keep changes focused and avoid committing credentials or generated logs. For database changes, add an ordered, repeatable migration and document the expected schema version. Tests should preferably mock provider responses so they can run without API credentials or quota.

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE).

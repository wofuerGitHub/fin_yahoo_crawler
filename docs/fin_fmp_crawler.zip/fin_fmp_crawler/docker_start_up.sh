#!/bin/bash

### build-images

docker build --pull --rm -f "src/docker/dockerfile_companykeystats" -t fmp_crawler_companykeystats:latest .
docker build --pull --rm -f "src/docker/dockerfile_statement" -t fmp_crawler_statement:latest .
docker build --pull --rm -f "src/docker/dockerfile_stream" -t fmp_crawler_stream:latest .
docker build --pull --rm -f "src/docker/dockerfile_symbolslist" -t fmp_crawler_symbolslist:latest .
docker build --pull --rm -f "src/docker/dockerfile_timeserie" -t fmp_crawler_timeserie:latest .

### build containers

# docker compose --project-name "fmp" -f "src/docker/docker-compose_fmp.yml" up -d --build

### copy images to host

docker save fmp_crawler_companykeystats:latest | bzip2 | pv | ssh wolfgang@149.102.143.132 docker load
docker save fmp_crawler_statement:latest | bzip2 | pv | ssh wolfgang@149.102.143.132 docker load
docker save fmp_crawler_stream:latest | bzip2 | pv | ssh wolfgang@149.102.143.132 docker load
docker save fmp_crawler_symbolslist:latest | bzip2 | pv | ssh wolfgang@149.102.143.132 docker load
docker save fmp_crawler_timeserie:latest | bzip2 | pv | ssh wolfgang@149.102.143.132 docker load

### delete old images

# docker rmi $(docker images -f dangling=true -q)

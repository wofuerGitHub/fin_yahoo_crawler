#!/bin/bash

docker run --rm -v fmp_db_vol:/volume -v $(pwd)/backup:/backup \busybox tar cvf /backup/fmp_db_vol.tar -C /volume .
